# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from datetime import datetime
from copy import deepcopy
import json
import shutil
import uuid
import re
import webbrowser

from logic import (
    new_diagnosis,
    add_situation,
    add_belief1,
    add_feeling,
    add_belief2,
    add_instinct,
    set_instinct,
    set_result,
    create_demo,
    INSTINCTS,
)


# ==========================================================
# СПРАВОЧНИК ПОДСКАЗОК
# Это ПРИМЕРЫ для специалиста. Клиент может назвать
# собственное убеждение, которого здесь нет.
# ==========================================================

PRIMARY_BELIEF_HINTS = [
    "Я недостаточно хорошая / хороший",
    "Я недостаточно компетентная / компетентный",
    "Я ничего не умею",
    "Я не справляюсь",
    "Я не способна / не способен",
    "Я слабая / слабый",
    "Я глупая / глупый",
    "Я неудачница / неудачник",
    "Я хуже других",
    "Я недостаточно умная / умный",
    "Я недостаточно красивая / красивый",
    "Я недостойна / недостоин",
    "Я не заслуживаю",
    "Я никому не нужна / не нужен",
    "Меня не любят",
    "Меня отвергнут",
    "Со мной что-то не так",
    "Я всё делаю неправильно",
    "Я должна / должен быть лучше",
    "Я обязан / обязана справляться",
    "Я не имею права ошибаться",
    "Я не имею права проявляться",
    "Я не имею права говорить о себе",
    "Я не могу доверять себе",
    "Мне нельзя доверять другим",
    "Я должна / должен всё контролировать",
    "Я должен / должна быть сильным",
    "Я не могу показать слабость",
    "Я один / одна",
    "Я беспомощная / беспомощный",
]


SECONDARY_FEELINGS = [
    "Боль",
    "Обида",
    "Страх",
    "Стыд",
    "Вина",
    "Грусть",
    "Злость",
    "Разочарование",
    "Одиночество",
    "Беспомощность",
    "Тревога",
    "Унижение",
    "Зависть",
    "Ревность",
]

# Цвета ситуаций. Каждая ситуация получает свой мягкий цвет,
# который повторяется в списке слева и в заголовке текущей ситуации.
SITUATION_COLORS = [
    ("#E8E1FF", "#5B4BA3"),
    ("#DDF0FF", "#2F6F9F"),
    ("#DDF6EA", "#287A55"),
    ("#FFE8D8", "#A85A2A"),
    ("#FCE0EA", "#A34A68"),
    ("#E2F1F1", "#347477"),
    ("#FFF0C9", "#9A6A16"),
    ("#E7EAF7", "#4E5C8A"),
]

# Цвета уровней диагностики в дереве.
TREE_COLORS = {
    "primary": "#FFF0D8",    # оранжевый
    "feeling": "#FFF7C7",    # жёлтый
    "deep": "#F9DADA",       # красный
    "instinct": "#ECEFF1",   # серый
}

RESULT_COLOR = "#DDF2E3"      # зелёный
RESULT_TEXT_COLOR = "#28613A"


class MainWindow:

    def __init__(self, root):
        self.root = root
        self.root.title("Психологическая диагностика")
        self.root.state("normal")
        self.root.geometry("1450x800")
        self.root.minsize(1250, 740)
        self.root.configure(bg="#EEF1F4")

        self.diagnosis = new_diagnosis()
        self.selected_situation = None
        self.selected_element = None
        self.selected_instinct_index = 0

        # --------------------------------------------------
        # БАЗА КЛИЕНТОВ
        # --------------------------------------------------
        # ==================================================
        # ОТДЕЛЬНАЯ ПАПКА БАЗЫ
        # ==================================================
        # Она находится рядом с папками ui / output и содержит
        # ВСЕ данные клиентов: фото, заметки, файлы и историю
        # занятий.
        #
        # DATABASE/
        #   database.json
        #   clients/
        #       <ФИО>__<ID>/
        #           profile.json
        #           photo.jpg
        #           notes.txt
        #           files/
        #           sessions/
        #               session_001/
        #                   session.json
        #                   notes.txt
        #                   files/
        self.data_dir = (
            Path(__file__).resolve().parent.parent / "DATABASE"
        )
        self.clients_file = (
            self.data_dir / "database.json"
        )
        self.clients_root = (
            self.data_dir / "clients"
        )
        self.photos_dir = (
            self.clients_root
        )
        self.clients = self.load_clients_db()

        self.current_client_id = None
        self.current_session_number = 1
        self.current_photo_path = ""
        self.current_query_id = None
        self.session_saved = False

        # Открытое окно базы клиентов. Нужно для обновления списка
        # после создания/редактирования/удаления клиента.
        self.client_database_window = None
        self.client_database_refresh = None

        # Временная база. Каждую минуту сюда пишется рабочий черновик.
        self.temp_data_dir = (
            Path(__file__).resolve().parent.parent / "TEMP_DATABASE"
        )
        self.temp_clients_root = self.temp_data_dir / "clients"
        self.autosave_interval = 60_000
        self.autosave_job = None
        self.last_autosave = None

        # Иконки социальных сетей из assets/social.
        self.social_icons = self._load_social_icons()

        self.build_style()
        self.build_interface()
        self.schedule_autosave()

        self.root.protocol(
            "WM_DELETE_WINDOW",
            self.on_app_close
        )

    # ======================================================
    # СТИЛЬ
    # ======================================================

    def situation_colors(self, index):
        return SITUATION_COLORS[index % len(SITUATION_COLORS)]

    def build_style(self):
        style = ttk.Style()

        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(
            "Treeview",
            background="#FFFFFF",
            fieldbackground="#FFFFFF",
            foreground="#202124",
            rowheight=30,
            font=("Segoe UI", 10),
        )

        # Выделение оставляем заметным, но не перекрываем
        # смысловую цветовую систему слишком тёмным синим.

        style.configure(
            "Treeview.Heading",
            background="#E5E9EE",
            foreground="#202124",
            font=("Segoe UI", 9, "bold"),
        )

        style.map(
            "Treeview",
            background=[("selected", "#DCE7F8")],
            foreground=[("selected", "#202124")],
        )

    # ======================================================
    # ИНТЕРФЕЙС
    # ======================================================

    def build_interface(self):

        header = tk.Frame(self.root, bg="#EEF1F4")
        header.pack(fill="x", padx=18, pady=(10, 7))

        tk.Label(
            header,
            text="Психологическая диагностика",
            font=("Segoe UI", 20, "bold"),
            bg="#EEF1F4",
            fg="#202124",
        ).pack(side="left")

        tk.Button(
            header,
            text="Сохранить TXT",
            command=self.save_txt,
            bg="#4169E1",
            fg="white",
            relief="flat",
            font=("Segoe UI", 10),
            padx=16,
            pady=7,
            cursor="hand2",
        ).pack(side="right")

        tk.Button(
            header,
            text="Сохранить в историю",
            command=self.save_history,
            bg="#287A55",
            fg="white",
            relief="flat",
            font=("Segoe UI", 10),
            padx=14,
            pady=7,
            cursor="hand2",
        ).pack(side="right", padx=(0, 8))

        main = tk.Frame(self.root, bg="#EEF1F4")
        main.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        # Геометрия панелей не зависит от того, какой редактор открыт.
        # Левая и правая панели имеют стабильную ширину.
        # Всё свободное место на большом окне получает только центр.
        main.grid_columnconfigure(0, weight=0, minsize=300)
        main.grid_columnconfigure(1, weight=1, minsize=500)
        main.grid_columnconfigure(2, weight=0, minsize=380)
        main.grid_rowconfigure(0, weight=1)

        self.build_left(main)
        self.build_center(main)
        self.build_right(main)

        # По умолчанию открывается рабочая область клиента.
        # Диагностика показывается только после нажатия кнопки «Диагностика».
        self.build_client_home(main)
        self.show_client_mode()

        # Нормальный буфер обмена Windows для всех текстовых полей.
        # Добавляем поверх стандартных Tk-команд Ctrl+C/X/V и контекстное меню.
        self.install_clipboard_support()

    # ======================================================
    # СОЦИАЛЬНЫЕ СЕТИ
    # ======================================================

    def _load_social_icons(self):
        """Загрузить пользовательские иконки VK / Telegram / MAX."""
        icons = {}
        try:
            from PIL import Image, ImageTk
            assets = Path(__file__).resolve().parent.parent / "assets" / "social"
            for key, filename in (("vk", "vk.png"), ("telegram", "tg.png"), ("max", "max.png")):
                path = assets / filename
                if path.exists():
                    image = Image.open(path).convert("RGBA")
                    image.thumbnail((22, 22), Image.LANCZOS)
                    icons[key] = ImageTk.PhotoImage(image)
        except Exception:
            pass
        return icons

    def _open_social_link(self, value):
        value = (value or "").strip()
        if not value:
            return
        if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", value):
            value = "https://" + value
        try:
            webbrowser.open(value, new=2)
        except Exception as exc:
            messagebox.showerror("Социальная сеть", f"Не удалось открыть ссылку:\n{exc}")

    def _social_button(self, parent, key, link_getter, padx=(0, 0)):
        image = self.social_icons.get(key)
        if image is None:
            return None
        button = tk.Label(parent, image=image, bg="white", cursor="hand2", bd=0, relief="flat")
        button.image = image
        button.pack(side="left", padx=padx)
        button.bind("<Button-1>", lambda _e: self._open_social_link(link_getter()))
        return button

    def _refresh_compact_social_icons(self, client):
        if not hasattr(self, "social_icons_row"):
            return
        for widget in self.social_icons_row.winfo_children():
            widget.destroy()
        for key in ("vk", "telegram", "max"):
            if client.get(key, "") and self.social_icons.get(key):
                self._social_button(
                    self.social_icons_row,
                    key,
                    lambda key=key, client=client: client.get(key, ""),
                    padx=(1, 2),
                )

    # ======================================================
    # ЛЕВАЯ ПАНЕЛЬ
    # ======================================================

    def build_left(self, parent):

        panel = self.panel(parent, 0)

        # ==================================================
        # КАРТОЧКА КЛИЕНТА
        # ==================================================
        card = tk.Frame(
            panel,
            bg="white",
            highlightbackground="#D7DBE0",
            highlightthickness=1,
        )
        card.pack(
            fill="x",
            padx=8,
            pady=8,
        )

        tk.Label(
            card,
            text="КЛИЕНТ",
            bg="white",
            fg="#202124",
            font=("Segoe UI", 10, "bold"),
        ).pack(
            anchor="w",
            padx=8,
            pady=(7, 5),
        )

        self.client_selector = ttk.Combobox(
            card,
            state="readonly",
            font=("Segoe UI", 9),
        )
        self.client_selector.pack(
            fill="x",
            padx=8,
            pady=(0, 7),
        )
        self.client_selector.bind(
            "<<ComboboxSelected>>",
            self.on_client_selected,
        )

        profile_row = tk.Frame(
            card,
            bg="white",
        )
        profile_row.pack(
            fill="x",
            padx=8,
            pady=(0, 7),
        )

        # ----------------------------------------------
        # ФОТО — прямоугольная карточка аватара.
        # Фото всегда полностью заполняет рамку с сохранением
        # пропорций (лишнее обрезается по краям).
        # ----------------------------------------------
        photo_column = tk.Frame(
            profile_row,
            bg="white",
            width=205,
            height=270,
        )
        photo_column.pack(
            side="left",
            fill="y",
        )
        photo_column.pack_propagate(False)

        photo_frame = tk.Frame(
            photo_column,
            bg="#F1F3F5",
            width=195,
            height=225,
            relief="solid",
            bd=1,
        )
        photo_frame.pack(padx=5, pady=5)
        photo_frame.pack_propagate(False)

        self.photo_label = tk.Label(
            photo_frame,
            text="Фото",
            bg="#F1F3F5",
            fg="#9CA3AF",
            anchor="center",
            cursor="hand2",
        )
        self.photo_label.pack(fill="both", expand=True)
        self.photo_label.bind("<Button-1>", lambda _e: self.choose_client_photo())

        # Иконки находятся непосредственно под фото и не должны обрезаться.
        self.social_icons_row = tk.Frame(
            photo_column,
            bg="white",
            height=28,
        )
        self.social_icons_row.pack(
            fill="x",
            pady=(3, 0),
        )
        self.social_icons_row.pack_propagate(False)

        # Фото редактируется по клику прямо на изображение.

        # ----------------------------------------------
        # ДАННЫЕ КЛИЕНТА.
        # В основной карточке показываем только ФИО, город и возраст.
        # Остальные поля сохраняются в модели клиента, но не загромождают UI.
        # ----------------------------------------------
        fields = tk.Frame(profile_row, bg="white")
        fields.pack(side="left", fill="both", expand=True, padx=(8, 0))

        def editable_field(parent, label_text):
            tk.Label(parent, text=label_text, bg="white", fg="#6B7280", font=("Segoe UI", 8)).pack(anchor="w")
            entry = tk.Entry(parent, font=("Segoe UI", 9), bg="#F8F9FA", relief="solid", borderwidth=1)
            entry.pack(fill="x", pady=(1, 3))
            return entry

        # Видимые поля.
        self.client_name = editable_field(fields, "ФИО")

        row_visible = tk.Frame(fields, bg="white")
        row_visible.pack(fill="x", pady=(2, 0))
        row_visible.columnconfigure(0, weight=1)
        row_visible.columnconfigure(1, weight=1)

        city_box = tk.Frame(row_visible, bg="white")
        city_box.grid(row=0, column=0, sticky="ew", padx=(0, 4))
        tk.Label(city_box, text="Город", bg="white", fg="#6B7280", font=("Segoe UI", 8)).pack(anchor="w")
        self.client_city = tk.Entry(city_box, font=("Segoe UI", 9), bg="#F8F9FA", relief="solid", borderwidth=1)
        self.client_city.pack(fill="x", pady=(1, 3))

        age_box = tk.Frame(row_visible, bg="white")
        age_box.grid(row=0, column=1, sticky="ew", padx=(4, 0))
        tk.Label(age_box, text="Возраст", bg="white", fg="#6B7280", font=("Segoe UI", 8)).pack(anchor="w")
        self.client_age = tk.Entry(age_box, font=("Segoe UI", 9), bg="#F1F3F5", readonlybackground="#F1F3F5", relief="solid", borderwidth=1, state="readonly")
        self.client_age.pack(fill="x", pady=(1, 3))

        # Служебные поля: остаются доступными логике сохранения/загрузки,
        # но не отображаются в основной карточке клиента.
        hidden_fields = tk.Frame(self.root)

        self.client_phone = tk.Entry(hidden_fields)
        self.client_email = tk.Entry(hidden_fields)
        self.client_gender = ttk.Combobox(hidden_fields, values=["", "Мужчина", "Женщина", "Другое"])
        self.client_country = tk.Entry(hidden_fields)
        self.client_birth_date = tk.Entry(hidden_fields)
        self.client_birth_date.bind("<FocusOut>", self.on_birth_date_changed)
        self.client_birth_date.bind("<Return>", self.on_birth_date_changed)
        self.client_vk = tk.Entry(hidden_fields)
        self.client_telegram = tk.Entry(hidden_fields)
        self.client_max = tk.Entry(hidden_fields)
        self.session_number = ttk.Spinbox(hidden_fields, from_=1, to=9999, width=6, state="readonly")
        self._set_main_spinbox(1)

        self.profile_save_button = self.button(
            fields,
            "Сохранить данные",
            lambda: self.save_client_profile(notify=True),
        )
        self.profile_save_button.pack(anchor="w", pady=(4, 2))

        profile_actions = tk.Frame(fields, bg="white")
        profile_actions.pack(anchor="w", fill="x")

        self.database_button = self.button(
            profile_actions,
            "База клиентов",
            self.open_client_database,
        )
        self.database_button.pack(side="left")

        # Кнопка возврата из диагностики к карте клиента.
        # В обычном режиме скрыта, в режиме диагностики показывается
        # рядом с кнопкой «База клиентов».
        self.back_to_progress_button = tk.Button(
            profile_actions,
            text="← Назад к карте прогресса",
            command=self.show_client_mode,
            font=("Segoe UI", 9, "bold"),
            bg="#238B57",
            fg="white",
            activebackground="#1B6F46",
            activeforeground="white",
            relief="flat",
            padx=10,
            pady=5,
            cursor="hand2",
        )
        self.back_to_progress_button.pack(
            side="left",
            padx=(8, 0),
        )
        self.back_to_progress_button.pack_forget()

        # ==================================================
        # РАБОТА С КЛИЕНТОМ
        # ==================================================
        client_work = tk.Frame(
            card,
            bg="white",
        )
        client_work.pack(
            fill="x",
            padx=8,
            pady=(8, 8),
        )

        tk.Label(
            client_work,
            text="РАБОТА С КЛИЕНТОМ",
            bg="white",
            fg="#202124",
            font=("Segoe UI", 9, "bold"),
        ).pack(
            anchor="w",
            pady=(0, 4),
        )

        work_buttons = tk.Frame(
            client_work,
            bg="white",
        )
        work_buttons.pack(
            fill="x",
        )

        self.button(
            work_buttons,
            "Карточка клиента",
            self.open_client_workspace,
            primary=True,
        ).pack(
            side="left",
            fill="x",
            expand=True,
        )

        self.button(
            work_buttons,
            "Диагностика",
            self.open_diagnosis_menu,
        ).pack(
            side="left",
            fill="x",
            expand=True,
            padx=(5, 0),
        )

        # ==================================================
        # ДИАГНОСТИКА — отдельный режим
        # ==================================================
        self.diagnostics_left = tk.Frame(
            panel,
            bg="white",
        )
        self.diagnostics_left.pack(
            fill="both",
            expand=True,
        )

        # Нижняя панель действий закреплена внизу левой колонки.
        # Поэтому кнопки управления ситуациями и подсказки всегда видны
        # даже в обычном размере окна, а не только при разворачивании.
        self.diagnostics_footer = tk.Frame(
            self.diagnostics_left,
            bg="white",
        )
        self.diagnostics_footer.pack(
            side="bottom",
            fill="x",
            padx=8,
            pady=(0, 6),
        )

        ttk.Separator(
            self.diagnostics_left
        ).pack(
            fill="x",
            padx=8,
            pady=(0, 7),
        )

        # ==================================================
        # ЗАПРОСЫ КЛИЕНТА
        # ==================================================
        history_frame = tk.Frame(
            self.diagnostics_left,
            bg="white",
        )
        history_frame.pack(
            fill="x",
            padx=8,
            pady=(0, 7),
        )

        tk.Label(
            history_frame,
            text="ЗАПРОСЫ КЛИЕНТА",
            bg="white",
            fg="#202124",
            font=("Segoe UI", 8, "bold"),
        ).pack(anchor="w")

        query_row = tk.Frame(history_frame, bg="white")
        query_row.pack(fill="x", pady=(2, 0))

        self.diagnosis_history_var = tk.StringVar(
            value="Нет запросов"
        )
        self.diagnosis_history_combo = ttk.Combobox(
            query_row,
            textvariable=self.diagnosis_history_var,
            state="readonly",
            font=("Segoe UI", 9),
        )
        self.diagnosis_history_combo.pack(
            side="left",
            fill="x",
            expand=True,
        )
        self.diagnosis_history_combo.bind(
            "<<ComboboxSelected>>",
            self.on_diagnosis_history_selected,
        )

        self.add_query_button = self.button(
            query_row,
            "+ Добавить запрос",
            self.start_new_query,
        )
        self.add_query_button.pack(side="left", padx=(5, 0))

        self.delete_query_button = self.button(
            query_row,
            "Удалить запрос",
            self.delete_current_query,
        )
        self.delete_query_button.pack(side="left", padx=(5, 0))

        self._loading_diagnosis_history = False

        # ==================================================
        # ОБЩИЙ ЗАПРОС
        # ==================================================
        tk.Label(
            self.diagnostics_left,
            text="ОБЩИЙ ЗАПРОС",
            bg="white",
            fg="#202124",
            font=("Segoe UI", 9, "bold"),
        ).pack(
            anchor="w",
            padx=8,
        )

        self.request_text = tk.Text(
            self.diagnostics_left,
            height=2,
            wrap="word",
            font=("Segoe UI", 9),
            bg="#F8F9FA",
            relief="solid",
            borderwidth=1,
        )
        self.request_text.pack(
            fill="x",
            padx=8,
            pady=(3, 8),
        )

        # ==================================================
        # СИТУАЦИИ
        # ==================================================
        tk.Label(
            self.diagnostics_left,
            text="СИТУАЦИИ",
            bg="white",
            fg="#202124",
            font=("Segoe UI", 9, "bold"),
        ).pack(
            anchor="w",
            padx=8,
        )

        self.situation_list = tk.Listbox(
            self.diagnostics_left,
            height=4,
            font=("Segoe UI", 9),
            bg="#F8F9FA",
            selectbackground="#4169E1",
            selectforeground="white",
            relief="solid",
            borderwidth=1,
        )
        self.situation_list.pack(
            fill="x",
            padx=8,
            pady=(4, 6),
        )
        self.situation_list.bind(
            "<<ListboxSelect>>",
            self.on_situation_select,
        )

        buttons = tk.Frame(
            self.diagnostics_footer,
            bg="white"
        )
        buttons.pack(
            fill="x",
            padx=8,
            pady=(0, 6)
        )

        self.button(
            buttons,
            "+ Добавить",
            self.add_situation
        ).pack(
            side="left"
        )

        self.button(
            buttons,
            "Изменить",
            self.edit_situation
        ).pack(
            side="left",
            padx=3
        )

        self.button(
            buttons,
            "Удалить",
            self.delete_situation
        ).pack(
            side="left"
        )

        self.button(
            self.diagnostics_footer,
            "Подсказки — убеждения 1",
            self.open_primary_hints,
        ).pack(
            anchor="w",
            padx=8,
            pady=(2, 4),
        )

        self.refresh_client_selector()

    # ======================================================
    # РЕЖИМ РАБОТЫ С КЛИЕНТОМ
    # ======================================================

    def build_client_home(self, parent):
        self.client_home = tk.Frame(
            parent,
            bg="white",
            highlightbackground="#D7DBE0",
            highlightthickness=1,
        )

        self.client_home_title = tk.Label(
            self.client_home,
            text="КАРТА КЛИЕНТА",
            bg="white",
            fg="#202124",
            font=("Segoe UI", 16, "bold"),
        )
        self.client_home_title.pack(
            anchor="w",
            padx=20,
            pady=(20, 5),
        )

        self.client_home_name = tk.Label(
            self.client_home,
            text="Выберите клиента",
            bg="white",
            fg="#6B7280",
            font=("Segoe UI", 11),
        )
        self.client_home_name.pack(
            anchor="w",
            padx=20,
        )

        tk.Label(
            self.client_home,
            text="Здесь будет история работы и прогресс клиента.",
            bg="white",
            fg="#9CA3AF",
            font=("Segoe UI", 10),
        ).pack(
            anchor="w",
            padx=20,
            pady=(15, 0),
        )

    def show_client_mode(self):
        # Основной экран: карточка клиента слева + карта клиента справа.
        if hasattr(self, "back_to_progress_button"):
            self.back_to_progress_button.pack_forget()

        if hasattr(self, "center_panel"):
            self.center_panel.grid_remove()
        if hasattr(self, "right_panel"):
            self.right_panel.grid_remove()
        if hasattr(self, "diagnostics_left"):
            self.diagnostics_left.pack_forget()
        if hasattr(self, "client_home"):
            self.client_home.grid(
                row=0,
                column=1,
                columnspan=2,
                sticky="nsew",
                padx=4,
            )

        client = self._find_client(getattr(self, "current_client_id", None))
        if hasattr(self, "client_home_name"):
            self.client_home_name.configure(
                text=(
                    client.get("full_name", "")
                    if client else "Выберите клиента"
                )
            )

    def open_diagnosis_menu(self):
        """Меню входа в диагностику: новая / предыдущие / удалить."""
        if not self.current_client_id:
            messagebox.showinfo("Диагностика", "Сначала выбери клиента.")
            return

        win = tk.Toplevel(self.root)
        win.title("Диагностика")
        win.geometry("430x250")
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()
        win.configure(bg="#EEF1F4")

        tk.Label(
            win,
            text="ДИАГНОСТИКА",
            bg="#EEF1F4",
            fg="#202124",
            font=("Segoe UI", 15, "bold"),
        ).pack(anchor="w", padx=20, pady=(18, 5))

        tk.Label(
            win,
            text="Выбери, с какой диагностикой работать",
            bg="#EEF1F4",
            fg="#6B7280",
            font=("Segoe UI", 9),
        ).pack(anchor="w", padx=20, pady=(0, 14))

        body = tk.Frame(win, bg="white")
        body.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        self.button(
            body,
            "＋ Новая диагностика",
            lambda: (win.destroy(), self.start_new_diagnosis()),
            primary=True,
        ).pack(fill="x", padx=15, pady=(15, 6))

        self.button(
            body,
            "Предыдущие запросы",
            lambda: (win.destroy(), self.open_diagnosis_history_dialog()),
        ).pack(fill="x", padx=15, pady=6)

        self.button(
            body,
            "Удалить запрос",
            lambda: (win.destroy(), self.open_diagnosis_history_dialog(delete_mode=True)),
        ).pack(fill="x", padx=15, pady=6)

    def start_new_diagnosis(self):
        """Совместимость со старой кнопкой: создать новый запрос."""
        self.start_new_query()

    def start_new_query(self):
        """Создать новый независимый запрос текущего клиента."""
        if not self.current_client_id:
            messagebox.showinfo("Запрос", "Сначала выбери клиента.")
            return

        # Новый запрос получает новый идентификатор только после сохранения.
        # Пока пользователь его заполняет, current_query_id = None.
        self.current_query_id = None
        self.diagnosis = new_diagnosis()
        self.request_text.delete("1.0", "end")
        self.selected_situation = None
        self.selected_element = None
        self.situation_list.selection_clear(0, "end")
        self.refresh_situations()
        self.clear_diagnosis_center()
        self.clear_editor()
        self.hide_instinct()
        self.hide_result()
        self.session_saved = False
        self.show_diagnosis_mode()
        self.refresh_diagnosis_history_selector()
        self.request_text.focus_set()

    def _ensure_diagnosis_queries(self, client):
        """Создать новый корневой список запросов и мигрировать старую историю.

        Старые сохранения группируются по тексту общего запроса. Для каждого
        запроса берётся последняя сохранённая версия, поэтому старые дубли
        не превращаются в десятки отдельных запросов.
        """
        if client is None:
            return []

        queries = client.get("diagnosis_queries")
        changed = False
        if not isinstance(queries, list):
            queries = []
            client["diagnosis_queries"] = queries
            changed = True

        # Индекс уже существующих запросов.
        by_request = {}
        for q in queries:
            if not isinstance(q, dict):
                continue
            q.setdefault("id", uuid.uuid4().hex)
            q.setdefault("created_at", q.get("updated_at", datetime.now().isoformat(timespec="seconds")))
            q.setdefault("updated_at", q.get("created_at", datetime.now().isoformat(timespec="seconds")))
            q.setdefault("request", "")
            q.setdefault("diagnosis", new_diagnosis())
            key = q.get("request", "").strip()
            if key:
                by_request[key] = q

        # Миграция старой diagnosis_history.
        legacy_items = []
        for session in client.get("sessions", []):
            try:
                sn = int(session.get("number", 1))
            except Exception:
                sn = 1
            for item in session.get("diagnosis_history", []) or []:
                if not isinstance(item, dict):
                    continue
                request = (item.get("request") or item.get("diagnosis", {}).get("request", "") or "").strip()
                diagnosis = item.get("diagnosis")
                if not request or not isinstance(diagnosis, dict):
                    continue
                legacy_items.append((item.get("saved_at", ""), request, diagnosis, sn, item.get("id")))

        # Сначала самые старые, чтобы created_at сохранился корректно.
        legacy_items.sort(key=lambda x: x[0] or "")
        for saved_at, request, diagnosis, sn, legacy_id in legacy_items:
            existing = by_request.get(request)
            if existing is None:
                existing = {
                    "id": legacy_id or uuid.uuid4().hex,
                    "created_at": saved_at or datetime.now().isoformat(timespec="seconds"),
                    "updated_at": saved_at or datetime.now().isoformat(timespec="seconds"),
                    "request": request,
                    "diagnosis": deepcopy(diagnosis),
                    "session_number": sn,
                }
                queries.append(existing)
                by_request[request] = existing
                changed = True
            else:
                # Более новая версия полностью заменяет содержимое запроса.
                if (saved_at or "") > (existing.get("updated_at", "") or ""):
                    existing["diagnosis"] = deepcopy(diagnosis)
                    existing["request"] = request
                    existing["updated_at"] = saved_at or existing.get("updated_at")
                    existing["session_number"] = sn
                    changed = True

        # Если истории ещё не было, но у клиента есть сохранённая диагностика
        # в занятии, создаём один запрос из самой свежей сессии.
        if not queries:
            sessions = sorted(
                client.get("sessions", []),
                key=lambda s: int(s.get("number", 0)) if str(s.get("number", 0)).isdigit() else 0,
            )
            for session in reversed(sessions):
                diagnosis = session.get("diagnosis")
                request = (session.get("request") or (diagnosis or {}).get("request", "") or "").strip()
                if request and isinstance(diagnosis, dict):
                    stamp = session.get("date") or datetime.now().isoformat(timespec="seconds")
                    q = {
                        "id": uuid.uuid4().hex,
                        "created_at": stamp,
                        "updated_at": stamp,
                        "request": request,
                        "diagnosis": deepcopy(diagnosis),
                        "session_number": int(session.get("number", 1)),
                    }
                    queries.append(q)
                    changed = True
                    break

        if changed:
            self.save_clients_db()

        return queries

    def _current_client_queries(self):
        client = self._find_client(self.current_client_id)
        if client is None:
            return []
        return self._ensure_diagnosis_queries(client)

    def delete_current_query(self):
        """Удалить только выбранный общий запрос клиента."""
        if not self.current_client_id or not self.current_query_id:
            messagebox.showinfo("Запрос", "Сначала выбери запрос для удаления.")
            return

        client = self._find_client(self.current_client_id)
        if client is None:
            return

        queries = self._ensure_diagnosis_queries(client)
        query = next((q for q in queries if q.get("id") == self.current_query_id), None)
        if query is None:
            return

        request = query.get("request", "").strip() or "Без названия"
        if not messagebox.askyesno(
            "Удалить запрос",
            f"Удалить выбранный запрос?\n\n«{request}»\n\nВместе с ним будет удалена вся его диагностика.",
        ):
            return

        client["diagnosis_queries"] = [
            q for q in queries if q.get("id") != self.current_query_id
        ]

        # Удаляем соответствующую старую запись, если она использует тот же id.
        for session in client.get("sessions", []):
            session["diagnosis_history"] = [
                item for item in session.get("diagnosis_history", [])
                if item.get("id") != self.current_query_id
            ]

        self.save_clients_db()
        self.current_query_id = None

        remaining = client.get("diagnosis_queries", [])
        if remaining:
            remaining.sort(key=lambda q: q.get("updated_at", ""))
            self.load_query_into_editor(remaining[-1])
            self.refresh_diagnosis_history_selector(select_id=remaining[-1].get("id"))
        else:
            self.diagnosis = new_diagnosis()
            self.request_text.delete("1.0", "end")
            self.selected_situation = None
            self.selected_element = None
            self.refresh_situations()
            self.clear_diagnosis_center()
            self.clear_editor()
            self.hide_instinct()
            self.hide_result()
            self.refresh_diagnosis_history_selector()


    def clear_diagnosis_center(self):
        """Полностью очищает центральную часть диагностики."""
        self.situation_title.config(
            text="Выберите ситуацию",
            bg="white",
            fg="#202124",
            padx=0,
            pady=0,
        )
        self.situation_info.config(text="")
        self.selected_situation = None

        if hasattr(self, "tree"):
            for item in self.tree.get_children(""):
                self.tree.delete(item)

    def open_diagnosis_history_dialog(self, delete_mode=False):
        """Окно управления общими запросами текущего клиента."""
        client = self._find_client(self.current_client_id)
        if client is None:
            return

        queries = self._ensure_diagnosis_queries(client)
        queries = sorted(queries, key=lambda q: q.get("updated_at", ""))

        if not queries:
            messagebox.showinfo("Запросы", "У этого клиента пока нет сохранённых запросов.")
            return

        win = tk.Toplevel(self.root)
        win.title("Запросы клиента")
        win.geometry("760x430")
        win.transient(self.root)
        win.grab_set()
        win.configure(bg="#EEF1F4")

        tk.Label(
            win,
            text="ЗАПРОСЫ КЛИЕНТА",
            bg="#EEF1F4",
            fg="#202124",
            font=("Segoe UI", 13, "bold"),
        ).pack(anchor="w", padx=15, pady=(15, 10))

        frame = tk.Frame(win, bg="white")
        frame.pack(fill="both", expand=True, padx=15, pady=(0, 10))

        tree = ttk.Treeview(
            frame,
            columns=("number", "updated", "request"),
            show="headings",
            selectmode="browse",
        )
        tree.heading("number", text="№")
        tree.heading("updated", text="Изменён")
        tree.heading("request", text="Общий запрос")
        tree.column("number", width=55, anchor="center")
        tree.column("updated", width=150, anchor="center")
        tree.column("request", width=500)

        scroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        for index, query in enumerate(queries, start=1):
            try:
                updated = datetime.fromisoformat(query.get("updated_at", "")).strftime("%d/%m/%Y %H:%M")
            except Exception:
                updated = query.get("updated_at", "") or "Без даты"
            tree.insert(
                "", "end", iid=str(index - 1),
                values=(index, updated, query.get("request", "")),
            )

        def selected_query():
            selection = tree.selection()
            if not selection:
                messagebox.showwarning("Запрос", "Выбери запрос.", parent=win)
                return None
            return queries[int(selection[0])]

        def open_selected():
            query = selected_query()
            if query is None:
                return
            self.load_query_into_editor(query)
            self.refresh_diagnosis_history_selector(select_id=query.get("id"))
            win.destroy()
            self.show_diagnosis_mode()

        def delete_selected():
            query = selected_query()
            if query is None:
                return
            request = query.get("request", "").strip() or "Без названия"
            if not messagebox.askyesno(
                "Удалить запрос",
                f"Удалить запрос?\n\n«{request}»\n\nВся диагностика этого запроса будет удалена.",
                parent=win,
            ):
                return

            qid = query.get("id")
            client["diagnosis_queries"] = [q for q in queries if q.get("id") != qid]
            for session in client.get("sessions", []):
                session["diagnosis_history"] = [
                    item for item in session.get("diagnosis_history", [])
                    if item.get("id") != qid
                ]
            self.save_clients_db()

            if self.current_query_id == qid:
                self.current_query_id = None
                remaining = client.get("diagnosis_queries", [])
                if remaining:
                    remaining.sort(key=lambda q: q.get("updated_at", ""))
                    self.load_query_into_editor(remaining[-1])
                else:
                    self.start_new_query()

            win.destroy()
            self.refresh_diagnosis_history_selector(select_id=self.current_query_id)

        buttons = tk.Frame(win, bg="#EEF1F4")
        buttons.pack(fill="x", padx=15, pady=(0, 15))

        self.button(buttons, "Открыть выбранный", open_selected, primary=True).pack(side="left")
        self.button(buttons, "Удалить выбранный", delete_selected).pack(side="left", padx=6)
        self.button(buttons, "Закрыть", win.destroy).pack(side="right")

    def show_diagnosis_mode(self):
        # Диагностика возвращает ровно существующий трёхколоночный интерфейс.
        if hasattr(self, "back_to_progress_button"):
            self.back_to_progress_button.pack(
                side="left",
                padx=(8, 0),
            )

        if hasattr(self, "client_home"):
            self.client_home.grid_remove()
        if hasattr(self, "diagnostics_left"):
            self.diagnostics_left.pack(
                fill="both",
                expand=True,
            )
        if hasattr(self, "center_panel"):
            self.center_panel.grid(
                row=0,
                column=1,
                sticky="nsew",
                padx=4,
            )
        if hasattr(self, "right_panel"):
            self.right_panel.grid(
                row=0,
                column=2,
                sticky="nsew",
                padx=4,
            )

        self.refresh_diagnosis_history_selector()

    # ======================================================
    # ЦЕНТР
    # ======================================================

    def build_center(self, parent):

        panel = self.panel(parent, 1)
        self.center_panel = panel

        self.situation_title = tk.Label(
            panel,
            text="Выберите ситуацию",
            bg="white",
            fg="#202124",
            font=("Segoe UI", 15, "bold"),
        )
        self.situation_title.pack(
            anchor="w",
            padx=15,
            pady=(15, 2),
        )

        self.situation_info = tk.Label(
            panel,
            text="",
            bg="white",
            fg="#6B7280",
            font=("Segoe UI", 10),
        )
        self.situation_info.pack(
            anchor="w",
            padx=15,
            pady=(0, 10),
        )

        tree_frame = tk.Frame(panel, bg="white")
        tree_frame.pack(
            fill="both",
            expand=True,
            padx=15,
            pady=5,
        )

        self.tree = ttk.Treeview(
            tree_frame,
            show="tree",
        )

        self.tree.tag_configure(
            "primary",
            background=TREE_COLORS["primary"],
            foreground="#7A4B00",
        )
        self.tree.tag_configure(
            "feeling",
            background=TREE_COLORS["feeling"],
            foreground="#6D5A00",
        )
        self.tree.tag_configure(
            "deep",
            background=TREE_COLORS["deep"],
            foreground="#8A2F2F",
        )
        self.tree.tag_configure(
            "instinct",
            background=TREE_COLORS["instinct"],
            foreground="#4B5563",
        )

        self.tree.tag_configure(
            "active_selection",
            background="#4169E1",
            foreground="white",
            font=("Segoe UI", 10, "bold"),
        )

        scrollbar = ttk.Scrollbar(
            tree_frame,
            orient="vertical",
            command=self.tree.yview,
        )
        self.tree.configure(
            yscrollcommand=scrollbar.set
        )

        self.tree.pack(
            side="left",
            fill="both",
            expand=True,
        )
        scrollbar.pack(
            side="right",
            fill="y",
        )

        self.tree.bind(
            "<<TreeviewSelect>>",
            self.on_element_select,
        )

        buttons = tk.Frame(panel, bg="white")
        buttons.pack(
            fill="x",
            padx=15,
            pady=12,
        )

        self.button(
            buttons,
            "+ Убеждение 1",
            self.add_belief1,
        ).pack(side="left")

        self.button(
            buttons,
            "+ Вторичные чувства",
            self.add_feeling,
        ).pack(side="left", padx=5)

        self.button(
            buttons,
            "+ Убеждение 2",
            self.add_belief2,
        ).pack(side="left")

        self.button(
            buttons,
            "Удалить",
            self.delete_element,
        ).pack(side="right")

    # ======================================================
    # ПРАВАЯ ПАНЕЛЬ
    # ======================================================

    def build_right(self, parent):

        panel = self.panel(parent, 2)
        self.right_panel = panel

        tk.Label(
            panel,
            text="РЕДАКТОР",
            bg="white",
            fg="#202124",
            font=("Segoe UI", 10, "bold"),
        ).pack(
            anchor="w",
            padx=15,
            pady=(15, 7),
        )

        # --------------------------------------------------
        # РЕДАКТОР ОСНОВНОГО ЭЛЕМЕНТА
        # --------------------------------------------------
        self.element_editor_frame = tk.Frame(
            panel,
            bg="white",
        )
        self.element_editor_frame.pack(
            fill="x",
        )

        self.element_title = tk.Label(
            self.element_editor_frame,
            text="Элемент не выбран",
            bg="white",
            fg="#4169E1",
            font=("Segoe UI", 10, "bold"),
        )
        self.element_title.pack(
            anchor="w",
            padx=15,
        )

        self.element_text = tk.Text(
            self.element_editor_frame,
            height=3,
            width=1,
            wrap="word",
            undo=True,
            maxundo=-1,
            exportselection=False,
            font=("Segoe UI", 10),
            bg="#F8F9FA",
            relief="solid",
            borderwidth=1,
        )
        self.element_text.pack(
            fill="x",
            padx=15,
            pady=7,
        )

        self.element_level_label = tk.Label(
            self.element_editor_frame,
            text="Уровень 1–10",
            bg="white",
            fg="#202124",
        )
        self.element_level_label.pack(
            anchor="w",
            padx=15,
        )

        self.element_level = ttk.Spinbox(
            self.element_editor_frame,
            from_=1,
            to=10,
            width=5,
        )
        self.element_level.set("5")
        self.element_level.pack(
            anchor="w",
            padx=15,
            pady=4,
        )

        self.element_comment_label = tk.Label(
            self.element_editor_frame,
            text="Комментарий / уточнение",
            bg="white",
            fg="#202124",
        )
        self.element_comment_label.pack(
            anchor="w",
            padx=15,
            pady=(6, 0),
        )

        self.element_comment = tk.Text(
            self.element_editor_frame,
            height=3,
            width=1,
            wrap="word",
            undo=True,
            maxundo=-1,
            exportselection=False,
            font=("Segoe UI", 10),
            bg="#F8F9FA",
            relief="solid",
            borderwidth=1,
        )
        self.element_comment.pack(
            fill="x",
            padx=15,
            pady=6,
        )

        self.save_element_button = self.button(
            self.element_editor_frame,
            "Сохранить элемент",
            self.save_element,
            primary=True,
        )
        self.save_element_button.pack(
            anchor="w",
            padx=15,
            pady=(0, 10),
        )

        # --------------------------------------------------
        # РЕДАКТОР ИНСТИНКТА(ОВ)
        # --------------------------------------------------
        self.instinct_frame = tk.LabelFrame(
            panel,
            text="ИНСТИНКТЫ — только для убеждения 2",
            bg="white",
            fg="#202124",
            font=("Segoe UI", 9, "bold"),
        )
        self.instinct_frame.pack(
            fill="x",
            padx=15,
            pady=(0, 10),
        )

        self.instinct_selected_label = tk.Label(
            self.instinct_frame,
            text="Инстинкт 1",
            bg="white",
            fg="#4169E1",
            font=("Segoe UI", 9, "bold"),
        )
        self.instinct_selected_label.pack(
            anchor="w",
            padx=10,
            pady=(7, 2),
        )

        self.instinct_combo = ttk.Combobox(
            self.instinct_frame,
            values=INSTINCTS,
            state="readonly",
        )
        self.instinct_combo.pack(
            fill="x",
            padx=10,
            pady=(3, 4),
        )

        self.instinct_level_label = tk.Label(
            self.instinct_frame,
            text="Уровень 1–10",
            bg="white",
            fg="#202124",
        )
        self.instinct_level_label.pack(
            anchor="w",
            padx=10,
            pady=(2, 0),
        )

        self.instinct_level = ttk.Spinbox(
            self.instinct_frame,
            from_=1,
            to=10,
            width=5,
        )
        self.instinct_level.set("5")
        self.instinct_level.pack(
            anchor="w",
            padx=10,
            pady=3,
        )

        self.instinct_comment_label = tk.Label(
            self.instinct_frame,
            text="Комментарий / уточнение",
            bg="white",
            fg="#202124",
        )
        self.instinct_comment_label.pack(
            anchor="w",
            padx=10,
            pady=(3, 0),
        )

        self.instinct_comment = tk.Entry(
            self.instinct_frame,
            font=("Segoe UI", 9),
            bg="#F8F9FA",
        )
        self.instinct_comment.pack(
            fill="x",
            padx=10,
            pady=4,
        )

        instinct_buttons = tk.Frame(
            self.instinct_frame,
            bg="white",
        )
        instinct_buttons.pack(
            fill="x",
            padx=10,
            pady=(3, 8),
        )

        self.save_instinct_button = self.button(
            instinct_buttons,
            "Сохранить инстинкт",
            self.save_instinct,
            primary=True,
        )
        self.save_instinct_button.pack(side="left")

        self.add_instinct_button = self.button(
            instinct_buttons,
            "+ Добавить инстинкт",
            self.add_instinct,
        )
        self.add_instinct_button.pack(side="left", padx=6)

        self.instinct_frame.pack_forget()

        # --------------------------------------------------
        # ЖЕЛАЕМЫЙ РЕЗУЛЬТАТ СИТУАЦИИ
        # --------------------------------------------------
        self.result_label = tk.Label(
            panel,
            text="★ ЖЕЛАЕМЫЙ РЕЗУЛЬТАТ СИТУАЦИИ",
            bg=RESULT_COLOR,
            fg=RESULT_TEXT_COLOR,
            font=("Segoe UI", 9, "bold"),
            padx=8,
            pady=4,
        )
        self.result_label.pack(
            anchor="w",
            padx=15,
            pady=(3, 0),
        )

        self.result_text = tk.Text(
            panel,
            height=3,
            width=1,
            wrap="word",
            undo=True,
            maxundo=-1,
            exportselection=False,
            font=("Segoe UI", 10),
            bg="#F3FAF5",
            relief="solid",
            borderwidth=1,
        )
        self.result_text.pack(
            fill="x",
            padx=15,
            pady=6,
        )

        self.result_button = self.button(
            panel,
            "Сохранить результат",
            self.save_result,
        )
        self.result_button.pack(
            anchor="w",
            padx=15,
            pady=(0, 10),
        )

        self.hide_result()

    def install_clipboard_support(self):
        """Полностью рабочий Windows-буфер обмена для текстовых контролов."""
        classes = ("Text", "Entry", "TEntry", "TCombobox", "TSpinbox")
        bindings = (
            ("<Control-c>", self._clipboard_copy),
            ("<Control-x>", self._clipboard_cut),
            ("<Control-v>", self._clipboard_paste),
            ("<Control-Insert>", self._clipboard_copy),
            ("<Shift-Insert>", self._clipboard_paste),
            ("<Button-3>", self._clipboard_menu),
        )
        for cls in classes:
            for sequence, handler in bindings:
                self.root.bind_class(cls, sequence, handler)

    def _is_text_widget(self, widget):
        return isinstance(widget, (tk.Text, tk.Entry, ttk.Entry, ttk.Combobox, ttk.Spinbox))

    def _clipboard_has_selection(self, widget):
        try:
            if isinstance(widget, tk.Text):
                return bool(widget.tag_ranges("sel"))
            return bool(widget.selection_present())
        except (tk.TclError, AttributeError):
            return False

    def _clipboard_get_selection(self, widget):
        if isinstance(widget, tk.Text):
            return widget.get("sel.first", "sel.last")
        return widget.selection_get()

    def _entry_selection_bounds(self, widget):
        """Возвращает начало/конец выделения Entry/Combobox/Spinbox."""
        a = widget.index("anchor")
        b = widget.index("insert")
        return (min(a, b), max(a, b))

    def _clipboard_copy(self, event):
        widget = event.widget
        if not self._is_text_widget(widget):
            return
        try:
            if not self._clipboard_has_selection(widget):
                return "break"
            text = self._clipboard_get_selection(widget)
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            self.root.update()
        except tk.TclError:
            pass
        return "break"

    def _clipboard_cut(self, event):
        widget = event.widget
        if not self._is_text_widget(widget):
            return
        try:
            if not self._clipboard_has_selection(widget):
                return "break"
            text = self._clipboard_get_selection(widget)
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            self.root.update()

            if isinstance(widget, tk.Text):
                widget.delete("sel.first", "sel.last")
            else:
                start, end = self._entry_selection_bounds(widget)
                widget.delete(start, end)
                widget.icursor(start)
        except (tk.TclError, ValueError):
            pass
        return "break"

    def _clipboard_paste(self, event):
        widget = event.widget
        if not self._is_text_widget(widget):
            return
        try:
            text = self.root.clipboard_get()
            if isinstance(widget, tk.Text):
                if self._clipboard_has_selection(widget):
                    widget.delete("sel.first", "sel.last")
                widget.insert("insert", text)
            else:
                if self._clipboard_has_selection(widget):
                    start, end = self._entry_selection_bounds(widget)
                    widget.delete(start, end)
                    widget.icursor(start)
                widget.insert("insert", text)
        except tk.TclError:
            pass
        return "break"

    def _clipboard_select_all(self, widget):
        try:
            if isinstance(widget, tk.Text):
                widget.tag_add("sel", "1.0", "end-1c")
                widget.mark_set("insert", "end-1c")
            else:
                widget.select_range(0, "end")
                widget.icursor("end")
            widget.focus_set()
        except tk.TclError:
            pass

    def _clipboard_menu(self, event):
        widget = event.widget
        if not self._is_text_widget(widget):
            return

        menu = tk.Menu(self.root, tearoff=0)
        has_selection = self._clipboard_has_selection(widget)

        def run(handler):
            class E:
                pass
            e = E()
            e.widget = widget
            handler(e)

        menu.add_command(
            label="Копировать",
            state="normal" if has_selection else "disabled",
            command=lambda: run(self._clipboard_copy),
        )
        menu.add_command(
            label="Вырезать",
            state="normal" if has_selection else "disabled",
            command=lambda: run(self._clipboard_cut),
        )
        menu.add_command(
            label="Вставить",
            command=lambda: run(self._clipboard_paste),
        )
        menu.add_separator()
        menu.add_command(
            label="Выделить всё",
            command=lambda: self._clipboard_select_all(widget),
        )

        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
        return "break"

    # ======================================================
    # ОБЩИЕ UI
    # ======================================================

    def panel(self, parent, column):

        frame = tk.Frame(
            parent,
            bg="white",
            highlightbackground="#D7DBE0",
            highlightthickness=1,
        )

        panel_widths = {
            0: 300,
            1: 500,
            2: 380,
        }

        width = panel_widths.get(
            column,
            500
        )

        frame.configure(
            width=width
        )
        frame.grid_propagate(False)

        # Боковые панели НЕ растягиваются.
        # Растягивается только центральная.
        sticky = "nsw" if column == 0 else (
            "nse" if column == 2 else "nsew"
        )

        frame.grid(
            row=0,
            column=column,
            sticky=sticky,
            padx=4,
        )

        return frame

    def button(
        self,
        parent,
        text,
        command,
        primary=False,
    ):

        return tk.Button(
            parent,
            text=text,
            command=command,
            font=("Segoe UI", 9),
            bg="#4169E1" if primary else "#EEF1F5",
            fg="white" if primary else "#202124",
            activebackground="#3158D8",
            activeforeground="white",
            relief="flat",
            padx=9,
            pady=5,
            cursor="hand2",
        )

    # ======================================================
    # ПОДСКАЗКИ — ОТДЕЛЬНОЕ ПЕРЕТАСКИВАЕМОЕ ОКНО
    # ======================================================

    def open_primary_hints(self):

        if hasattr(self, "hints_window"):
            try:
                if self.hints_window.winfo_exists():
                    self.hints_window.lift()
                    self.hints_window.focus_force()
                    return
            except tk.TclError:
                pass

        self.hints_window = tk.Toplevel(self.root)
        self.hints_window.title(
            "Подсказки — ограничивающие убеждения 1"
        )
        self.hints_window.geometry("650x650")
        self.hints_window.minsize(500, 450)
        self.hints_window.configure(bg="white")

        top = tk.Frame(
            self.hints_window,
            bg="white"
        )
        top.pack(
            fill="x",
            padx=15,
            pady=(15, 8)
        )

        tk.Label(
            top,
            text="Примеры ограничивающих убеждений 1",
            font=("Segoe UI", 12, "bold"),
            bg="white",
            fg="#202124",
        ).pack(anchor="w")

        tk.Label(
            top,
            text=(
                "Это только подсказки для специалиста. "
                "Не нужно подгонять клиента под список."
            ),
            font=("Segoe UI", 9),
            bg="white",
            fg="#6B7280",
        ).pack(anchor="w", pady=(3, 8))

        search_var = tk.StringVar()

        search = tk.Entry(
            top,
            textvariable=search_var,
            font=("Segoe UI", 10),
            bg="#F8F9FA",
            relief="solid",
            borderwidth=1,
        )
        search.pack(
            fill="x"
        )

        body = tk.Frame(
            self.hints_window,
            bg="white"
        )
        body.pack(
            fill="both",
            expand=True,
            padx=15
        )

        listbox = tk.Listbox(
            body,
            font=("Segoe UI", 10),
            bg="#F8F9FA",
            selectbackground="#4169E1",
            selectforeground="white",
            relief="solid",
            borderwidth=1,
        )

        scroll = ttk.Scrollbar(
            body,
            orient="vertical",
            command=listbox.yview
        )
        listbox.configure(
            yscrollcommand=scroll.set
        )

        listbox.pack(
            side="left",
            fill="both",
            expand=True
        )
        scroll.pack(
            side="right",
            fill="y"
        )

        def refresh_hints(*_):

            phrase = search_var.get().strip().lower()

            listbox.delete(0, "end")

            for item in PRIMARY_BELIEF_HINTS:

                if not phrase or phrase in item.lower():
                    listbox.insert(
                        "end",
                        item
                    )

        refresh_hints()
        search_var.trace_add(
            "write",
            refresh_hints
        )

        bottom = tk.Frame(
            self.hints_window,
            bg="white"
        )
        bottom.pack(
            fill="x",
            padx=15,
            pady=12
        )

        def copy_hint():

            selection = listbox.curselection()

            if not selection:
                return

            value = listbox.get(selection[0])

            self.hints_window.clipboard_clear()
            self.hints_window.clipboard_append(value)
            self.hints_window.update()

        def use_hint():

            selection = listbox.curselection()

            if not selection:
                messagebox.showinfo(
                    "Подсказки",
                    "Выбери убеждение из списка."
                )
                return

            value = listbox.get(selection[0])

            self.element_text.delete(
                "1.0",
                "end"
            )
            self.element_text.insert(
                "1.0",
                value
            )

            self.hints_window.lift()

        self.button(
            bottom,
            "Копировать",
            copy_hint,
        ).pack(side="left")

        self.button(
            bottom,
            "Вставить в редактор",
            use_hint,
            primary=True,
        ).pack(
            side="left",
            padx=6
        )

        self.button(
            bottom,
            "Закрыть",
            self.hints_window.destroy,
        ).pack(side="right")

        # Окно НЕ modal: его можно двигать и одновременно работать
        # с основной программой.
        self.hints_window.transient(self.root)

    # ======================================================
    # БАЗА КЛИЕНТОВ
    # ======================================================

    def load_clients_db(self):
        self.data_dir.mkdir(
            parents=True,
            exist_ok=True
        )
        self.clients_root.mkdir(
            parents=True,
            exist_ok=True
        )

        # Если новой DATABASE ещё нет, пробуем подхватить
        # существующую старую базу из data/clients.json.
        source_file = self.clients_file

        if not source_file.exists():
            legacy_file = (
                Path(__file__).resolve().parent.parent
                / "data"
                / "clients.json"
            )

            source_file = (
                legacy_file
                if legacy_file.exists()
                else self.clients_file
            )

        if not source_file.exists():
            return []

        try:
            data = json.loads(
                source_file.read_text(
                    encoding="utf-8"
                )
            )
        except Exception:
            data = []

        if not isinstance(data, list):
            return []

        for client in data:
            client.setdefault("gender", "")
            client.setdefault("country", "РФ")
            client.setdefault("city", "")
            client.setdefault("birth_date", "")
            client.setdefault("age", self.calculate_age(client.get("birth_date", "")))
            client.setdefault("vk", "")
            client.setdefault("telegram", "")
            client.setdefault("max", "")

            client.setdefault(
                "notes",
                ""
            )
            client.setdefault(
                "files",
                []
            )
            client.setdefault(
                "diagnosis_queries",
                []
            )
            client.setdefault(
                "sessions",
                []
            )

            # У каждой сессии может быть несколько сохранённых
            # версий диагностики. Старые базы остаются совместимыми.
            for session in client.get("sessions", []):
                session.setdefault("diagnosis_history", [])

        # Пустые записи не являются клиентами. Они могли остаться
        # после отменённого создания нового клиента в старых версиях.
        # Удаляем только действительно пустые записи, не затрагивая
        # клиентов с ФИО.
        cleaned = [
            client for client in data
            if client.get("full_name", "").strip()
        ]

        # Если данные были найдены в старой папке,
        # переносим фото в новую DATABASE при сохранении.
        if len(cleaned) != len(data):
            data = cleaned
            try:
                self.clients_file.write_text(
                    json.dumps(data, ensure_ascii=False, indent=2),
                    encoding="utf-8"
                )
            except Exception:
                pass

        return data

    def client_folder(self, client):
        client_id = client.get(
            "id",
            ""
        )

        full_name = (
            client.get(
                "full_name",
                "Без имени"
            ).strip()
            or "Без имени"
        )

        # Безопасное имя папки Windows.
        safe_name = re.sub(
            r'[<>:"/\\|?*]',
            "_",
            full_name
        )

        safe_name = re.sub(
            r"\s+",
            " ",
            safe_name
        ).strip()

        folder = (
            self.clients_root
            / f"{safe_name}__{client_id[:8]}"
        )

        folder.mkdir(
            parents=True,
            exist_ok=True
        )

        (folder / "files").mkdir(
            parents=True,
            exist_ok=True
        )

        (folder / "sessions").mkdir(
            parents=True,
            exist_ok=True
        )

        return folder

    def session_folder(self, client, number):
        folder = (
            self.client_folder(client)
            / "sessions"
            / f"session_{int(number):03d}"
        )

        folder.mkdir(
            parents=True,
            exist_ok=True
        )

        (folder / "files").mkdir(
            parents=True,
            exist_ok=True
        )

        return folder

    def relative_data_path(self, path):
        try:
            return str(
                Path(path).resolve().relative_to(
                    self.data_dir.resolve()
                )
            )
        except Exception:
            return str(path)

    def absolute_data_path(self, path):
        if not path:
            return ""

        p = Path(path)

        if p.is_absolute():
            return str(p)

        return str(
            self.data_dir / p
        )

    def write_client_files(self, client):
        """
        Синхронизирует JSON-индекс и физическую структуру
        папки конкретного клиента.
        """
        folder = self.client_folder(client)

        profile = {
            key: value
            for key, value in client.items()
            if key not in (
                "sessions",
            )
        }

        # Путь к фото внутри profile.json делаем относительным.
        if profile.get("photo_path"):
            profile["photo_path"] = (
                self.relative_data_path(
                    profile["photo_path"]
                )
            )

        (folder / "profile.json").write_text(
            json.dumps(
                profile,
                ensure_ascii=False,
                indent=2
            ),
            encoding="utf-8"
        )

        (folder / "notes.txt").write_text(
            client.get(
                "notes",
                ""
            ),
            encoding="utf-8"
        )

        # Сессии физически хранятся по одной в своих папках.
        for session in client.get(
            "sessions",
            []
        ):
            try:
                number = int(
                    session.get(
                        "number",
                        1
                    )
                )
            except Exception:
                number = 1

            session_dir = self.session_folder(
                client,
                number
            )

            session_json = dict(
                session
            )

            # session.json не должен содержать
            # огромные абсолютные пути.
            session_json["attachments"] = [
                self.relative_data_path(item)
                if isinstance(item, str)
                else item
                for item in session.get(
                    "attachments",
                    []
                )
            ]

            (session_dir / "session.json").write_text(
                json.dumps(
                    session_json,
                    ensure_ascii=False,
                    indent=2
                ),
                encoding="utf-8"
            )

            (session_dir / "notes.txt").write_text(
                session.get(
                    "notes",
                    ""
                ),
                encoding="utf-8"
            )

    def save_clients_db(self):
        """Единая запись всей текущей постоянной базы клиента.

        Все новые функции, которые добавляют данные в self.clients,
        сохраняются здесь без отдельного списка полей.
        """
        self.data_dir.mkdir(
            parents=True,
            exist_ok=True
        )
        self.clients_root.mkdir(
            parents=True,
            exist_ok=True
        )

        for client in self.clients:
            self.write_client_files(
                client
            )

        # Индекс остаётся для быстрого списка клиентов.
        self.clients_file.write_text(
            json.dumps(
                self.clients,
                ensure_ascii=False,
                indent=2
            ),
            encoding="utf-8"
        )

    def refresh_client_selector(self):
        if not hasattr(self, "client_selector"):
            return

        values = [
            client.get("full_name", "")
            for client in self.clients
            if client.get("full_name", "").strip()
        ]

        self.client_selector["values"] = values

        if self.current_client_id:
            for i, client in enumerate(self.clients):
                if client.get("id") == self.current_client_id:
                    self.client_selector.current(i)
                    break

    def _find_client(self, client_id):
        for client in self.clients:
            if client.get("id") == client_id:
                return client
        return None

    def _client_by_name(self, name):
        name = name.strip().lower()
        for client in self.clients:
            if client.get("full_name", "").strip().lower() == name:
                return client
        return None

    def _set_main_entry(self, widget, value):
        """Записать значение в поле основной карточки независимо от его типа."""
        try:
            state = str(widget.cget("state"))
        except Exception:
            state = "normal"
        try:
            widget.configure(state="normal")
        except Exception:
            pass
        widget.delete(0, "end")
        widget.insert(0, value or "")
        if state == "readonly":
            try:
                widget.configure(state="readonly")
            except Exception:
                pass

    def _set_main_spinbox(self, value):
        self.session_number.configure(state="normal")
        self.session_number.set(str(value))
        self.session_number.configure(state="readonly")

    def new_client(self):
        self.current_client_id = None
        self.current_photo_path = ""
        self.current_session_number = 1
        self.current_query_id = None
        self.session_saved = False

        self.client_selector.set("")
        self._set_main_entry(self.client_name, "")
        self._set_main_entry(self.client_phone, "")
        self._set_main_entry(self.client_email, "")
        self.client_gender.set("")
        self.client_country.delete(0, "end")
        self.client_country.insert(0, "РФ")
        self.client_city.delete(0, "end")
        self.client_birth_date.delete(0, "end")
        self._set_main_entry(self.client_age, "")
        self.client_vk.delete(0, "end")
        self.client_telegram.delete(0, "end")
        self.client_max.delete(0, "end")
        self._set_main_spinbox(1)

        self.photo_label.configure(
            image="",
            text="Фото",
            bg="#F1F3F5",
            fg="#9CA3AF",
        )
        self._client_photo_image = None
        self._refresh_compact_social_icons({})

        self.diagnosis = new_diagnosis()
        self.request_text.delete("1.0", "end")
        self.selected_situation = None
        self.selected_element = None
        self.refresh_situations()
        self.clear_editor()
        self.hide_instinct()
        self.hide_result()
        self.show_client_mode()


    # ======================================================
    # ДАННЫЕ КЛИЕНТА
    # ======================================================

    def calculate_age(self, birth_date):
        if not birth_date:
            return ""
        value = str(birth_date).strip()
        for fmt in ("%d.%m.%Y", "%Y-%m-%d", "%d-%m-%Y"):
            try:
                birth = datetime.strptime(value, fmt).date()
                today = datetime.now().date()
                age = today.year - birth.year - ((today.month, today.day) < (birth.month, birth.day))
                return str(max(0, age))
            except ValueError:
                continue
        return ""

    def on_birth_date_changed(self, _event=None):
        value = self.client_birth_date.get().strip()
        age = self.calculate_age(value)
        self._set_main_entry(self.client_age, age)
        if value and not age:
            return
        if self.current_client_id and self.client_name.get().strip():
            self.save_client_profile(notify=False)

    # ======================================================
    # ТЕЛЕФОН
    # ======================================================

    def normalize_phone(self, value):
        digits = re.sub(r"\D", "", value)

        if not digits:
            return ""

        if digits.startswith("8"):
            digits = "7" + digits[1:]
        elif not digits.startswith("7"):
            digits = "7" + digits

        digits = digits[:11]

        if len(digits) <= 1:
            return "+7"
        if len(digits) <= 4:
            return "+7-" + digits[1:]
        if len(digits) <= 7:
            return "+7-" + digits[1:4] + "-" + digits[4:]
        if len(digits) <= 10:
            return (
                "+7-" + digits[1:4] + "-"
                + digits[4:7] + "-" + digits[7:]
            )

        return (
            "+7-" + digits[1:4] + "-"
            + digits[4:7] + "-" + digits[7:11]
        )

    def format_phone_entry(self, _event=None):
        value = self.client_phone.get()
        formatted = self.normalize_phone(value)
        if formatted != value:
            self.client_phone.delete(0, "end")
            self.client_phone.insert(0, formatted)

    def phone_is_valid(self, value):
        return bool(
            re.fullmatch(
                r"\+7-\d{3}-\d{3}-\d{4}",
                value
            )
        )

    def on_client_selected(self, _event=None):
        # Сначала сохраняем черновик клиента, с которым работали.
        self.autosave_now()

        index = self.client_selector.current()
        if index < 0 or index >= len(self.clients):
            return

        client = self.clients[index]

        self.current_client_id = client.get("id")
        self.current_photo_path = client.get("photo_path", "")
        self.session_saved = False

        self._set_main_entry(self.client_name, client.get("full_name", ""))

        self._set_main_entry(
            self.client_phone,
            self.normalize_phone(client.get("phone", ""))
        )

        self._set_main_entry(self.client_email, client.get("email", ""))
        self.client_gender.set(client.get("gender", ""))
        self.client_country.delete(0, "end")
        self.client_country.insert(0, client.get("country", "РФ") or "РФ")
        self.client_city.delete(0, "end")
        self.client_city.insert(0, client.get("city", ""))
        self.client_birth_date.delete(0, "end")
        self.client_birth_date.insert(0, client.get("birth_date", ""))
        self._set_main_entry(self.client_age, self.calculate_age(client.get("birth_date", "")) or client.get("age", ""))
        self.client_vk.delete(0, "end")
        self.client_vk.insert(0, client.get("vk", ""))
        self.client_telegram.delete(0, "end")
        self.client_telegram.insert(0, client.get("telegram", ""))
        self.client_max.delete(0, "end")
        self.client_max.insert(0, client.get("max", ""))

        self.show_client_photo(self.current_photo_path)
        self._refresh_compact_social_icons(client)

        queries = self._ensure_diagnosis_queries(client)

        if queries:
            queries = sorted(queries, key=lambda q: q.get("updated_at", ""))
            latest_query = queries[-1]
            self.current_query_id = latest_query.get("id")
            self.load_query_into_editor(latest_query)
        else:
            self.current_query_id = None
            sessions = client.get("sessions", [])
            if sessions:
                sessions = sorted(
                    sessions,
                    key=lambda s: int(s.get("number", 0))
                )
                latest = sessions[-1]
                number = int(latest.get("number", 1))
                self.current_session_number = number
                self._set_main_spinbox(number)
                self.load_session_into_editor(client, latest)
            else:
                self.current_session_number = 1
                self._set_main_spinbox(1)
                self.diagnosis = new_diagnosis()
                self.request_text.delete("1.0", "end")
                self.selected_situation = None
                self.selected_element = None
                self.refresh_situations()
                self.clear_editor()
                self.hide_instinct()
                self.hide_result()

        # Черновик автоматически НЕ восстанавливаем.
        # Минутное автосохранение продолжает работать.
        self.show_client_mode()

    def load_query_into_editor(self, query):
        """Открыть выбранный корневой запрос и всю его диагностику."""
        if not isinstance(query, dict):
            return

        self.current_query_id = query.get("id")
        self.diagnosis = deepcopy(query.get("diagnosis"))
        if not isinstance(self.diagnosis, dict):
            self.diagnosis = new_diagnosis()
        self.diagnosis["request"] = query.get("request", self.diagnosis.get("request", ""))

        if query.get("session_number") is not None:
            try:
                self.current_session_number = int(query.get("session_number"))
                self._set_main_spinbox(self.current_session_number)
            except Exception:
                pass

        self.request_text.delete("1.0", "end")
        self.request_text.insert("1.0", self.diagnosis.get("request", ""))
        self.selected_situation = None
        self.selected_element = None
        self.refresh_situations()
        self.clear_editor()
        self.hide_instinct()
        self.hide_result()

        situations = self.diagnosis.get("situations", [])
        if situations:
            self.selected_situation = situations[0]
            self.situation_list.selection_clear(0, "end")
            self.situation_list.selection_set(0)
            self.on_situation_select()

    def load_session_into_editor(self, client, session):
        diagnosis = deepcopy(session.get("diagnosis"))

        if not isinstance(diagnosis, dict):
            diagnosis = new_diagnosis()

        self.diagnosis = diagnosis
        self.diagnosis["request"] = session.get(
            "request",
            self.diagnosis.get("request", "")
        )

        self.request_text.delete("1.0", "end")
        self.request_text.insert(
            "1.0",
            self.diagnosis.get("request", "")
        )

        self.selected_situation = None
        self.selected_element = None
        self.refresh_situations()
        self.clear_editor()
        self.hide_instinct()
        self.hide_result()

        situations = self.diagnosis.get("situations", [])

        if situations:
            self.selected_situation = situations[0]
            self.situation_list.selection_clear(0, "end")
            self.situation_list.selection_set(0)
            self.on_situation_select()

    def open_client_workspace(self, client_override=None):
        """Открыть отдельную карточку клиента для просмотра/редактирования."""
        client = client_override or self._find_client(self.current_client_id)
        if client is None:
            messagebox.showinfo("Работа с клиентом", "Сначала выбери клиента.")
            return

        if hasattr(self, "client_workspace_window"):
            try:
                if self.client_workspace_window.winfo_exists():
                    self.client_workspace_window.lift()
                    self._load_workspace_fields(client)
                    return
            except tk.TclError:
                pass

        win = tk.Toplevel(self.root)
        self.client_workspace_window = win
        win.title(f"Работа с клиентом — {client.get('full_name', '')}")
        win.geometry("980x820")
        win.minsize(850, 700)
        win.configure(bg="#EEF1F4")

        tk.Label(win, text="РАБОТА С КЛИЕНТОМ", bg="#EEF1F4", fg="#202124",
                 font=("Segoe UI", 17, "bold")).pack(anchor="w", padx=18, pady=(15, 10))

        body = tk.Frame(win, bg="white", highlightbackground="#D7DBE0", highlightthickness=1)
        body.pack(fill="both", expand=True, padx=18, pady=(0, 10))

        top = tk.Frame(body, bg="white")
        top.pack(fill="x", padx=18, pady=18)

        photo_box = tk.Frame(top, bg="white")
        photo_box.pack(side="left")

        self.workspace_photo_label = tk.Label(photo_box, text="Фото", bg="#F1F3F5", fg="#9CA3AF",
                                               relief="solid", borderwidth=1)
        self.workspace_photo_label.configure(width=220, height=250)
        self.workspace_photo_label.pack()
        photo_box.pack_propagate(False)
        photo_box.configure(width=220)

        def choose_workspace_photo():
            path = filedialog.askopenfilename(
                title="Выбрать фото клиента",
                filetypes=[("Изображения", "*.png *.jpg *.jpeg *.gif *.bmp *.webp"), ("Все файлы", "*.*")],
            )
            if not path:
                return
            folder = self.client_folder(client)
            source = Path(path)
            extension = source.suffix.lower() or ".jpg"
            target = folder / f"photo{extension}"
            try:
                shutil.copy2(source, target)
                for old_photo in folder.glob("photo.*"):
                    if old_photo != target:
                        try:
                            old_photo.unlink()
                        except Exception:
                            pass
                client["photo_path"] = str(target)
                self.current_photo_path = str(target)
                self._show_workspace_photo(str(target))
                self.save_clients_db() if client.get("full_name", "").strip() else None
            except Exception as exc:
                messagebox.showerror("Фото", f"Не удалось сохранить фото:\n{exc}")

        self.button(photo_box, "Загрузить фото", choose_workspace_photo).pack(fill="x", pady=(5, 0))

        data = tk.Frame(top, bg="white")
        data.pack(side="left", fill="both", expand=True, padx=(15, 0))
        for c in range(4):
            data.grid_columnconfigure(c, weight=1)

        def grid_entry(label, row, col, colspan=1, readonly=False):
            box = tk.Frame(data, bg="white")
            box.grid(row=row, column=col, columnspan=colspan, sticky="ew", padx=4, pady=(0, 7))
            tk.Label(box, text=label, bg="white", fg="#6B7280",
                     font=("Segoe UI", 8)).pack(anchor="w")
            state = "readonly" if readonly else "normal"
            e = ttk.Entry(box, font=("Segoe UI", 10), state=state)
            e.pack(fill="x", pady=(2, 0))
            return e

        self.workspace_name = grid_entry("ФИО", 0, 0, 4)
        self.workspace_phone = grid_entry("Телефон", 1, 0, 2)
        self.workspace_email = grid_entry("E-mail", 1, 2, 2)

        gender_box = tk.Frame(data, bg="white")
        gender_box.grid(row=2, column=0, sticky="ew", padx=4, pady=(0, 7))
        tk.Label(gender_box, text="Пол", bg="white", fg="#6B7280", font=("Segoe UI", 8)).pack(anchor="w")
        self.workspace_gender = ttk.Combobox(gender_box, values=["", "Мужской", "Женский"], state="readonly")
        self.workspace_gender.pack(fill="x", pady=(2, 0))

        self.workspace_country = grid_entry("Страна", 2, 1)
        self.workspace_city = grid_entry("Город", 2, 2)
        self.workspace_birth_date = grid_entry("Дата рождения", 2, 3)
        self.workspace_age = grid_entry("Возраст", 3, 0, 1, readonly=False)

        def social_grid_entry(key, label, row, col):
            box = tk.Frame(data, bg="white")
            box.grid(row=row, column=col, sticky="ew", padx=4, pady=(0, 7))
            head = tk.Frame(box, bg="white")
            head.pack(fill="x")
            icon = self.social_icons.get(key)
            if icon is not None:
                icon_label = tk.Label(head, image=icon, bg="white", cursor="hand2")
                icon_label.image = icon
                icon_label.pack(side="left", padx=(0, 5))
                icon_label.bind("<Button-1>", lambda _e, key=key: self._open_social_link(getattr(self, f"workspace_{key}").get()))
            tk.Label(head, text=label, bg="white", fg="#6B7280", font=("Segoe UI", 8)).pack(side="left")
            e = ttk.Entry(box, font=("Segoe UI", 10))
            e.pack(fill="x", pady=(2, 0))
            return e

        self.workspace_vk = social_grid_entry("vk", "VK", 3, 1)
        self.workspace_telegram = social_grid_entry("telegram", "Telegram", 3, 2)
        self.workspace_max = social_grid_entry("max", "MAX", 3, 3)

        def update_workspace_age(_event=None):
            birth_value = self.workspace_birth_date.get().strip()
            calculated = self.calculate_age(birth_value)
            if calculated:
                self.workspace_age.delete(0, "end")
                self.workspace_age.insert(0, calculated)
        self.workspace_birth_date.bind("<KeyRelease>", update_workspace_age)

        fields = tk.Frame(body, bg="white")
        fields.pack(fill="both", expand=True, padx=18, pady=(0, 10))
        canvas = tk.Canvas(fields, bg="white", highlightthickness=0)
        scroll = ttk.Scrollbar(fields, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg="white")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw", width=650)
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        def text_field(label):
            tk.Label(inner, text=label, bg="white", fg="#202124",
                     font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(7, 3))
            t = tk.Text(inner, height=3, wrap="word", font=("Segoe UI", 10),
                        bg="#F8F9FA", relief="solid", borderwidth=1)
            t.pack(fill="x")
            return t

        self.workspace_came_with = text_field("С чем пришёл")
        self.workspace_main_request = text_field("Основной запрос")
        self.workspace_already_tried = text_field("Что уже делал")
        self.workspace_did_not_help = text_field("Что не помогло")
        self.workspace_desired_result = text_field("Какой результат хочет получить")
        self.workspace_source = text_field("Откуда узнал обо мне")
        self.workspace_notes = text_field("Заметки о клиенте")

        def close_workspace():
            # Новый клиент до сохранения существует только как черновик
            # и поэтому вообще не должен попадать в DATABASE.
            if getattr(self, "_workspace_is_new_client", False):
                self._new_client_draft = None
                self.current_client_id = None
                self.current_photo_path = ""
                self._set_main_entry(self.client_name, "")
                self._set_main_entry(self.client_phone, "")
                self._set_main_entry(self.client_email, "")
                self._set_main_spinbox(1)
                self.photo_label.configure(image="", text="Фото", bg="#F1F3F5", fg="#9CA3AF")
                self._client_photo_image = None
                self._refresh_compact_social_icons({})
            self._workspace_is_new_client = False
            win.destroy()
            self._refresh_client_database_if_open()

        win.protocol("WM_DELETE_WINDOW", close_workspace)

        bottom = tk.Frame(win, bg="#EEF1F4")
        bottom.pack(fill="x", padx=18, pady=(0, 15))
        self.button(bottom, "Сохранить карточку", self.save_client_workspace, primary=True).pack(side="right")
        self.button(bottom, "Закрыть", close_workspace).pack(side="right", padx=(0, 8))
        self._load_workspace_fields(client)

    def _load_workspace_fields(self, client):
        def set_entry(widget, value):
            widget.delete(0, "end")
            widget.insert(0, value or "")
        def set_text(widget, value):
            widget.delete("1.0", "end")
            widget.insert("1.0", value or "")
        set_entry(self.workspace_name, client.get("full_name"))
        set_entry(self.workspace_phone, self.normalize_phone(client.get("phone", "")))
        set_entry(self.workspace_email, client.get("email"))
        self.workspace_gender.set(client.get("gender", ""))
        set_entry(self.workspace_country, client.get("country", "РФ") or "РФ")
        set_entry(self.workspace_city, client.get("city", ""))
        set_entry(self.workspace_birth_date, client.get("birth_date", ""))
        set_entry(self.workspace_age, self.calculate_age(client.get("birth_date", "")) or client.get("age", ""))
        set_entry(self.workspace_vk, client.get("vk", ""))
        set_entry(self.workspace_telegram, client.get("telegram", ""))
        set_entry(self.workspace_max, client.get("max", ""))
        set_text(self.workspace_came_with, client.get("came_with"))
        set_text(self.workspace_main_request, client.get("main_request"))
        set_text(self.workspace_already_tried, client.get("already_tried"))
        set_text(self.workspace_did_not_help, client.get("did_not_help"))
        set_text(self.workspace_desired_result, client.get("desired_result"))
        set_text(self.workspace_source, client.get("source"))
        set_text(self.workspace_notes, client.get("notes"))
        self._show_workspace_photo(client.get("photo_path", ""))

    def _show_workspace_photo(self, path):
        if not path or not Path(path).exists():
            self.workspace_photo_label.configure(image="", text="Фото")
            self._workspace_photo_image = None
            return
        try:
            from PIL import Image, ImageTk
            from PIL import ImageOps
            image = Image.open(path).convert("RGB")
            image = ImageOps.fit(image, (220, 250), method=Image.LANCZOS, centering=(0.5, 0.5))
            photo = ImageTk.PhotoImage(image)
            self._workspace_photo_image = photo
            self.workspace_photo_label.configure(image=photo, text="")
        except Exception:
            self.workspace_photo_label.configure(image="", text="Фото")
            self._workspace_photo_image = None

    def save_client_workspace(self):
        # При создании нового клиента берём временную карточку,
        # а в постоянную БД добавляем только после успешной проверки ФИО.
        if getattr(self, "_workspace_is_new_client", False):
            client = getattr(self, "_new_client_draft", None)
        else:
            client = self._find_client(self.current_client_id)
        if client is None:
            return
        name = self.workspace_name.get().strip()
        if not name:
            messagebox.showwarning("Клиент", "Укажи ФИО.")
            return
        phone = self.normalize_phone(self.workspace_phone.get().strip())
        if phone and not self.phone_is_valid(phone):
            messagebox.showwarning("Телефон", "Телефон должен быть в формате:\n+7-123-456-7890")
            return
        client["full_name"] = name
        client["phone"] = phone
        client["email"] = self.workspace_email.get().strip()
        client["gender"] = self.workspace_gender.get().strip()
        client["country"] = self.workspace_country.get().strip() or "РФ"
        client["city"] = self.workspace_city.get().strip()
        client["birth_date"] = self.workspace_birth_date.get().strip()
        manual_age = self.workspace_age.get().strip()
        calculated_age = self.calculate_age(client["birth_date"])
        client["age"] = calculated_age or manual_age
        client["vk"] = self.workspace_vk.get().strip()
        client["telegram"] = self.workspace_telegram.get().strip()
        client["max"] = self.workspace_max.get().strip()
        client["came_with"] = self.workspace_came_with.get("1.0", "end").strip()
        client["main_request"] = self.workspace_main_request.get("1.0", "end").strip()
        client["already_tried"] = self.workspace_already_tried.get("1.0", "end").strip()
        client["did_not_help"] = self.workspace_did_not_help.get("1.0", "end").strip()
        client["desired_result"] = self.workspace_desired_result.get("1.0", "end").strip()
        client["source"] = self.workspace_source.get("1.0", "end").strip()
        client["notes"] = self.workspace_notes.get("1.0", "end").strip()

        if getattr(self, "_workspace_is_new_client", False):
            # Если фото было выбрано до сохранения ФИО, оно могло
            # временно попасть в папку «Без имени». После сохранения
            # карточки переносим его в нормальную папку клиента.
            old_photo = Path(client.get("photo_path", "")) if client.get("photo_path") else None
            self.clients.append(client)
            self.current_client_id = client.get("id")
            self._new_client_draft = None

            if old_photo and old_photo.exists():
                try:
                    final_folder = self.client_folder(client)
                    final_photo = final_folder / old_photo.name
                    if old_photo.resolve() != final_photo.resolve():
                        shutil.copy2(old_photo, final_photo)
                        client["photo_path"] = str(final_photo)
                        try:
                            old_folder = old_photo.parent
                            if old_folder.name.startswith("Без имени__"):
                                shutil.rmtree(old_folder, ignore_errors=True)
                        except Exception:
                            pass
                except Exception:
                    pass

        self.save_clients_db()
        self.refresh_client_selector()
        self._refresh_client_database_if_open()
        self._set_main_entry(self.client_name, client.get("full_name", ""))
        self._set_main_entry(self.client_phone, self.normalize_phone(client.get("phone", "")))
        self._set_main_entry(self.client_email, client.get("email", ""))
        self.client_gender.set(client.get("gender", ""))
        self.client_country.delete(0, "end")
        self.client_country.insert(0, client.get("country", "РФ") or "РФ")
        self.client_city.delete(0, "end")
        self.client_city.insert(0, client.get("city", ""))
        self.client_birth_date.delete(0, "end")
        self.client_birth_date.insert(0, client.get("birth_date", ""))
        self._set_main_entry(self.client_age, self.calculate_age(client.get("birth_date", "")) or client.get("age", ""))
        self.client_vk.delete(0, "end")
        self.client_vk.insert(0, client.get("vk", ""))
        self.client_telegram.delete(0, "end")
        self.client_telegram.insert(0, client.get("telegram", ""))
        self.client_max.delete(0, "end")
        self.client_max.insert(0, client.get("max", ""))
        self.current_photo_path = client.get("photo_path", "")
        self.show_client_photo(self.current_photo_path)
        self._refresh_compact_social_icons(client)
        self._workspace_is_new_client = False
        messagebox.showinfo("Клиент", "Карточка клиента сохранена.")

    def save_client_profile(self, notify=True):
        name = self.client_name.get().strip()

        if not name:
            messagebox.showwarning(
                "Клиент",
                "Укажи ФИО клиента."
            )
            return None

        try:
            session_number = int(
                self.session_number.get()
            )
        except (TypeError, ValueError):
            session_number = 1

        if self.current_client_id:
            client = self._find_client(
                self.current_client_id
            )
        else:
            client = None

        # Если человек уже существует, не создаём дубль.
        if client is None:
            client = self._client_by_name(name)

        if client is None:
            client = {
                "id": uuid.uuid4().hex,
                "full_name": name,
                "phone": "",
                "email": "",
                "gender": "",
                "country": "РФ",
                "city": "",
                "birth_date": "",
                "age": "",
                "vk": "",
                "telegram": "",
                "max": "",
                "photo_path": "",
                "created_at": datetime.now().isoformat(
                    timespec="seconds"
                ),
                "notes": "",
                "files": [],
                "diagnosis_queries": [],
                "sessions": [],
            }
            self.clients.append(client)

        phone = self.normalize_phone(
            self.client_phone.get().strip()
        )

        if phone and not self.phone_is_valid(phone):
            messagebox.showwarning(
                "Телефон",
                "Телефон должен быть в формате:\n+7-123-456-7890"
            )
            return None

        self._set_main_entry(self.client_phone, phone)

        client["full_name"] = name
        client["phone"] = phone
        client["email"] = self.client_email.get().strip()
        client["gender"] = self.client_gender.get().strip()
        client["country"] = self.client_country.get().strip() or "РФ"
        client["city"] = self.client_city.get().strip()
        client["birth_date"] = self.client_birth_date.get().strip()
        manual_age = self.client_age.get().strip()
        calculated_age = self.calculate_age(client["birth_date"])
        client["age"] = calculated_age or manual_age
        client["vk"] = self.client_vk.get().strip()
        client["telegram"] = self.client_telegram.get().strip()
        client["max"] = self.client_max.get().strip()
        client["photo_path"] = self.current_photo_path
        self._set_main_entry(self.client_age, client["age"])

        self.current_client_id = client["id"]
        self.current_session_number = max(
            1,
            session_number
        )
        self._set_main_spinbox(self.current_session_number)

        self.save_clients_db()
        self.refresh_client_selector()
        self._refresh_compact_social_icons(client)
        self.session_saved = False

        if notify:
            messagebox.showinfo(
                "Клиент",
                f"Карточка клиента сохранена.\n\n{name}"
            )

        return client

    def choose_client_photo(self):
        path = filedialog.askopenfilename(
            title="Выбрать фото клиента",
            filetypes=[
                ("Изображения", "*.png *.jpg *.jpeg *.gif *.bmp *.webp"),
                ("Все файлы", "*.*"),
            ],
        )
        if not path:
            return

        self._open_photo_cropper(path)

    def _open_photo_cropper(self, path):
        """Редактор прямоугольного аватара: масштаб, перетаскивание и кадрирование."""
        try:
            from PIL import Image, ImageTk
            source = Image.open(path).convert("RGB")
        except Exception as exc:
            messagebox.showerror("Фото", f"Не удалось открыть фото:\n{exc}")
            return

        win = tk.Toplevel(self.root)
        win.title("Фото клиента — кадрирование")
        win.geometry("700x790")
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()

        tk.Label(win, text="Настройте фото клиента", font=("Segoe UI", 15, "bold")).pack(pady=(16, 4))
        tk.Label(win, text="Фото полностью заполнит прямоугольную карточку. Меняйте масштаб и перетаскивайте изображение мышью.", font=("Segoe UI", 10), fg="#5B6470").pack(pady=(0, 10))

        canvas_w, canvas_h = 500, 540
        crop_w, crop_h = 380, 440
        canvas = tk.Canvas(win, width=canvas_w, height=canvas_h, bg="#1F2329", highlightthickness=0)
        canvas.pack(pady=8)

        zoom_var = tk.DoubleVar(value=1.0)
        zoom_value = tk.StringVar(value="100%")
        state = {"x": 0.0, "y": 0.0, "drag_x": 0, "drag_y": 0, "dragging": False}

        def render(*_):
            from PIL import Image, ImageTk
            z = max(1.0, float(zoom_var.get()))
            base = max(crop_w / source.width, crop_h / source.height)
            nw = max(crop_w, int(source.width * base * z))
            nh = max(crop_h, int(source.height * base * z))
            img = source.resize((nw, nh), Image.LANCZOS)
            max_x = max(0, (nw - crop_w) / 2)
            max_y = max(0, (nh - crop_h) / 2)
            state["x"] = max(-max_x, min(max_x, state["x"]))
            state["y"] = max(-max_y, min(max_y, state["y"]))
            left = int((nw - crop_w) / 2 - state["x"])
            top = int((nh - crop_h) / 2 - state["y"])
            cropped = img.crop((left, top, left + crop_w, top + crop_h))
            photo = ImageTk.PhotoImage(cropped)
            canvas.delete("all")
            x0 = (canvas_w - crop_w) // 2
            y0 = (canvas_h - crop_h) // 2
            canvas.create_rectangle(x0, y0, x0 + crop_w, y0 + crop_h, outline="white", width=4)
            canvas.create_image(x0, y0, anchor="nw", image=photo)
            canvas.create_rectangle(x0, y0, x0 + crop_w, y0 + crop_h, outline="white", width=4)
            canvas._photo = photo
            zoom_value.set(f"{int(float(zoom_var.get()) * 100)}%")

        def start_drag(event):
            state["dragging"] = True
            state["drag_x"] = event.x
            state["drag_y"] = event.y

        def drag(event):
            if state["dragging"]:
                state["x"] += event.x - state["drag_x"]
                state["y"] += event.y - state["drag_y"]
                state["drag_x"] = event.x
                state["drag_y"] = event.y
                render()

        def stop_drag(_event):
            state["dragging"] = False

        def wheel(event):
            step = 0.1 if event.delta > 0 else -0.1
            zoom_var.set(max(1.0, min(4.0, round(float(zoom_var.get()) + step, 2))))
            render()

        canvas.bind("<ButtonPress-1>", start_drag)
        canvas.bind("<B1-Motion>", drag)
        canvas.bind("<ButtonRelease-1>", stop_drag)
        canvas.bind("<MouseWheel>", wheel)

        controls = tk.Frame(win)
        controls.pack(fill="x", padx=90, pady=(8, 4))
        row = tk.Frame(controls)
        row.pack(fill="x")
        tk.Button(row, text="−", width=3, command=lambda: (zoom_var.set(max(1.0, float(zoom_var.get()) - 0.1)), render())).pack(side="left")
        ttk.Scale(row, from_=1.0, to=4.0, variable=zoom_var, command=render).pack(side="left", fill="x", expand=True, padx=10)
        tk.Button(row, text="+", width=3, command=lambda: (zoom_var.set(min(4.0, float(zoom_var.get()) + 0.1)), render())).pack(side="left")
        tk.Label(controls, textvariable=zoom_value, font=("Segoe UI", 10, "bold")).pack(pady=(4, 0))

        tk.Label(win, text="Белая рамка — итоговая прямоугольная область фотографии.", fg="#6B7280", font=("Segoe UI", 9)).pack(pady=4)

        buttons = tk.Frame(win)
        buttons.pack(pady=12)

        def save_crop():
            try:
                from PIL import Image
                z = max(1.0, float(zoom_var.get()))
                base = max(crop_w / source.width, crop_h / source.height)
                nw = max(crop_w, int(source.width * base * z))
                nh = max(crop_h, int(source.height * base * z))
                img = source.resize((nw, nh), Image.LANCZOS)
                max_x = max(0, (nw - crop_w) / 2)
                max_y = max(0, (nh - crop_h) / 2)
                state["x"] = max(-max_x, min(max_x, state["x"]))
                state["y"] = max(-max_y, min(max_y, state["y"]))
                left = int((nw - crop_w) / 2 - state["x"])
                top = int((nh - crop_h) / 2 - state["y"])
                cropped = img.crop((left, top, left + crop_w, top + crop_h))

                if not self.current_client_id:
                    client = self.save_client_profile(notify=False)
                else:
                    client = self._find_client(self.current_client_id)
                if client is None:
                    return
                folder = self.client_folder(client)
                folder.mkdir(parents=True, exist_ok=True)
                target = folder / "photo.png"
                cropped.save(target, "PNG")
                for old_photo in folder.glob("photo.*"):
                    if old_photo != target:
                        try:
                            old_photo.unlink()
                        except Exception:
                            pass
                self.current_photo_path = str(target)
                client["photo_path"] = str(target)
                self.show_client_photo(self.current_photo_path)
                self.save_clients_db()
                win.grab_release()
                win.destroy()
            except Exception as exc:
                messagebox.showerror("Фото", f"Не удалось сохранить фото:\n{exc}", parent=win)

        tk.Button(buttons, text="Сохранить фото", command=save_crop, bg="#2E8B57", fg="white", relief="flat", padx=20, pady=9).pack(side="left", padx=6)
        tk.Button(buttons, text="Отмена", command=lambda: (win.grab_release(), win.destroy()), relief="flat", padx=20, pady=9).pack(side="left", padx=6)
        render()

    def show_client_photo(self, path):
        if not path or not Path(path).exists():
            self.photo_label.configure(image="", text="Фото", bg="#F1F3F5", fg="#9CA3AF")
            self._client_photo_image = None
            return
        try:
            from PIL import Image, ImageTk, ImageOps
            image = Image.open(path).convert("RGB")
            size = (190, 220)
            # Прямоугольная карточка полностью заполняется фото
            # без искажения пропорций: лишнее аккуратно обрезается.
            image = ImageOps.fit(image, size, method=Image.LANCZOS, centering=(0.5, 0.5))
            photo = ImageTk.PhotoImage(image)
            self._client_photo_image = photo
            self.photo_label.configure(image=photo, text="", bg="white")
        except Exception:
            self.photo_label.configure(image="", text="Фото", bg="#F1F3F5", fg="#9CA3AF")
            self._client_photo_image = None

    def current_session_snapshot(self):
        if not self.current_client_id:
            return None

        try:
            number = int(self.session_number.get())
        except Exception:
            number = 1

        client = self._find_client(self.current_client_id)
        if client is None:
            return None

        diagnosis = deepcopy(self.diagnosis)
        diagnosis["request"] = self.request_text.get(
            "1.0", "end"
        ).strip()

        return {
            "client_id": client["id"],
            "client_name": client.get("full_name", ""),
            "session_number": number,
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "phone": client.get("phone", ""),
            "email": client.get("email", ""),
            "photo_path": client.get("photo_path", ""),
            "diagnosis": diagnosis,
        }

    def temp_session_folder(self, client_id, number):
        folder = (
            self.temp_clients_root
            / client_id
            / f"session_{int(number):03d}"
        )
        (folder / "backups").mkdir(
            parents=True,
            exist_ok=True
        )
        return folder

    def autosave_now(self):
        snapshot = self.current_session_snapshot()
        if snapshot is None:
            return False

        try:
            folder = self.temp_session_folder(
                snapshot["client_id"],
                snapshot["session_number"]
            )

            payload = json.dumps(
                snapshot,
                ensure_ascii=False,
                indent=2
            )

            (folder / "current.json").write_text(
                payload,
                encoding="utf-8"
            )

            backup = (
                folder / "backups"
                / (
                    "backup_"
                    + datetime.now().strftime("%Y%m%d_%H%M%S")
                    + ".json"
                )
            )
            backup.write_text(
                payload,
                encoding="utf-8"
            )

            backups = sorted(
                (folder / "backups").glob("backup_*.json"),
                key=lambda p: p.stat().st_mtime,
                reverse=True
            )

            # Максимум 120 минутных резервных копий.
            for old in backups[120:]:
                try:
                    old.unlink()
                except Exception:
                    pass

            self.last_autosave = datetime.now()
            return True

        except Exception:
            return False

    def schedule_autosave(self):
        self.autosave_job = self.root.after(
            self.autosave_interval,
            self._autosave_tick
        )

    def _autosave_tick(self):
        try:
            self.autosave_now()
        finally:
            self.schedule_autosave()

    def read_temp_snapshot(self, client_id, number):
        path = (
            self.temp_clients_root
            / client_id
            / f"session_{int(number):03d}"
            / "current.json"
        )

        if not path.exists():
            return None

        try:
            return json.loads(
                path.read_text(encoding="utf-8")
            )
        except Exception:
            return None

    def try_restore_temp(self):
        if not self.current_client_id:
            return

        root = (
            self.temp_clients_root
            / self.current_client_id
        )

        if not root.exists():
            return

        candidates = []

        for current_file in root.glob(
            "session_*/current.json"
        ):
            try:
                data = json.loads(
                    current_file.read_text(
                        encoding="utf-8"
                    )
                )
                candidates.append(data)
            except Exception:
                pass

        if not candidates:
            return

        candidates.sort(
            key=lambda x: x.get("saved_at", ""),
            reverse=True
        )

        snapshot = candidates[0]

        try:
            temp_time = datetime.fromisoformat(
                snapshot.get("saved_at", "")
            )
        except Exception:
            return

        number = int(
            snapshot.get("session_number", 1)
        )

        client = self._find_client(
            self.current_client_id
        )
        if client is None:
            return

        saved_time = datetime.min

        for session in client.get("sessions", []):
            try:
                if int(session.get("number", -1)) == number:
                    saved_time = datetime.fromisoformat(
                        session.get("date", "")
                    )
                    break
            except Exception:
                pass

        if temp_time <= saved_time:
            return

        if not messagebox.askyesno(
            "Найден черновик",
            (
                "Найдена незавершённая работа.\n\n"
                f"Клиент: {client.get('full_name', '')}\n"
                f"Занятие №{number}\n"
                f"Автосохранение: {snapshot.get('saved_at', '')}\n\n"
                "Восстановить?"
            )
        ):
            return

        diagnosis = deepcopy(
            snapshot.get("diagnosis")
        )

        if not isinstance(diagnosis, dict):
            return

        self.current_session_number = number
        self._set_main_spinbox(number)
        self.diagnosis = diagnosis

        self.request_text.delete("1.0", "end")
        self.request_text.insert(
            "1.0",
            diagnosis.get("request", "")
        )

        self.selected_situation = None
        self.selected_element = None
        self.refresh_situations()
        self.clear_editor()
        self.hide_instinct()
        self.hide_result()

        situations = diagnosis.get("situations", [])
        if situations:
            self.selected_situation = situations[0]
            self.situation_list.selection_clear(0, "end")
            self.situation_list.selection_set(0)
            self.on_situation_select()

    def clear_temp_session(self):
        if not self.current_client_id:
            return

        try:
            number = int(self.session_number.get())
        except Exception:
            number = 1

        current = (
            self.temp_session_folder(
                self.current_client_id,
                number
            )
            / "current.json"
        )

        try:
            if current.exists():
                current.unlink()
        except Exception:
            pass

    def save_history(self, silent=False, avoid_duplicate=False):
        """Сохранить текущий ОБЩИЙ ЗАПРОС. Повторное сохранение обновляет его."""
        if not self.client_name.get().strip():
            if not silent:
                messagebox.showwarning("История клиента", "Сначала выбери или создай клиента.")
            return False

        current_request = self.request_text.get("1.0", "end").strip()
        current_situations = self.diagnosis.get("situations", []) or []
        if not current_request and not current_situations:
            if not silent:
                messagebox.showwarning("Запрос", "Заполни общий запрос или добавь ситуацию.")
            return False

        if not self.save_current_session_to_db():
            return False

        client = self._find_client(self.current_client_id)
        if client is None:
            return False

        queries = self._ensure_diagnosis_queries(client)
        snapshot = deepcopy(self.diagnosis)
        snapshot["request"] = current_request
        saved_at = datetime.now().isoformat(timespec="seconds")

        query = None
        if self.current_query_id:
            query = next((q for q in queries if q.get("id") == self.current_query_id), None)

        if query is None:
            # Новый запрос создаётся только здесь — при первом сохранении нового запроса.
            query = {
                "id": uuid.uuid4().hex,
                "created_at": saved_at,
                "updated_at": saved_at,
                "request": current_request,
                "diagnosis": snapshot,
                "session_number": int(self.session_number.get()),
            }
            queries.append(query)
            self.current_query_id = query["id"]
            action = "создан"
        else:
            query["updated_at"] = saved_at
            query["request"] = current_request
            query["diagnosis"] = snapshot
            query["session_number"] = int(self.session_number.get())
            action = "обновлён"

        # Если старый history-item существует с тем же id, синхронизируем его.
        # Новые сохранения больше не добавляются в diagnosis_history.
        for session in client.get("sessions", []):
            for item in session.get("diagnosis_history", []) or []:
                if item.get("id") == self.current_query_id:
                    item["saved_at"] = saved_at
                    item["request"] = current_request
                    item["diagnosis"] = deepcopy(snapshot)

        self.save_clients_db()
        self.session_saved = True
        self.refresh_diagnosis_history_selector(select_id=self.current_query_id)

        if not silent:
            display_date = datetime.fromisoformat(saved_at).strftime("%d/%m/%Y %H:%M")
            messagebox.showinfo(
                "Запрос",
                f"Запрос {action}.\n\nДата сохранения: {display_date}",
            )
        return True

    def refresh_diagnosis_history_selector(self, select_id=None):
        """Показать список независимых общих запросов клиента."""
        combo = getattr(self, "diagnosis_history_combo", None)
        if combo is None:
            return

        client = self._find_client(self.current_client_id)
        if client is None:
            self._diagnosis_history_items = []
            self._loading_diagnosis_history = True
            try:
                combo["values"] = ("Нет запросов",)
                self.diagnosis_history_var.set("Нет запросов")
            finally:
                self._loading_diagnosis_history = False
            return

        queries = self._ensure_diagnosis_queries(client)
        queries = sorted(queries, key=lambda q: q.get("updated_at", ""))
        self._diagnosis_history_items = queries

        labels = []
        id_to_label = {}
        for index, item in enumerate(queries, start=1):
            request = (item.get("request", "") or "Без названия").strip().replace("\n", " ")
            if len(request) > 75:
                request = request[:72] + "..."
            label = f"Запрос {index}: {request}"
            labels.append(label)
            id_to_label[item.get("id")] = label

        self._loading_diagnosis_history = True
        try:
            if not labels:
                combo["values"] = ("Нет запросов",)
                self.diagnosis_history_var.set("Нет запросов")
                self.current_query_id = None
            else:
                combo["values"] = labels
                target = select_id or self.current_query_id
                if target in id_to_label:
                    self.diagnosis_history_var.set(id_to_label[target])
                else:
                    self.diagnosis_history_var.set(labels[-1])
        finally:
            self._loading_diagnosis_history = False

    def on_diagnosis_history_selected(self, event=None):
        if self._loading_diagnosis_history:
            return

        combo = getattr(self, "diagnosis_history_combo", None)
        if combo is None:
            return

        index = combo.current()
        if index < 0:
            return

        queries = getattr(self, "_diagnosis_history_items", [])
        if index >= len(queries):
            return

        query = queries[index]
        self.load_query_into_editor(query)
        self.refresh_diagnosis_history_selector(select_id=self.current_query_id)

    def on_app_close(self):
        """Закрытие программы с явным выбором сохранения всех изменений."""
        answer = messagebox.askyesnocancel(
            "Закрыть программу",
            "Сохранить все изменения перед закрытием?\n\n"
            "Будут сохранены текущие данные клиента, результаты диагностики "
            "и изменения текущего запроса.",
            parent=self.root,
        )

        if answer is None:
            return

        if answer:
            # Сохраняем полный рабочий набор данных: профиль клиента,
            # текущую сессию, текущий запрос и всю диагностику.
            ok = False
            try:
                self.autosave_now()
                ok = self.save_history(silent=True, avoid_duplicate=True)
                # Финальная запись всей базы — единая точка сохранения.
                self.save_clients_db()
            except Exception as exc:
                messagebox.showerror(
                    "Ошибка сохранения",
                    f"Не удалось полностью сохранить изменения.\n\n{exc}",
                    parent=self.root,
                )
                return

            if not ok:
                # Если текущая диагностика ещё не заполнена, всё равно
                # сохраняем профиль/прочие изменения клиента.
                try:
                    self.save_client_profile(notify=False)
                    self.save_clients_db()
                except Exception as exc:
                    messagebox.showerror(
                        "Ошибка сохранения",
                        f"Не удалось сохранить изменения.\n\n{exc}",
                        parent=self.root,
                    )
                    return
        else:
            # Перед выходом сохраняем только временный черновик,
            # но НЕ записываем его в постоянную базу.
            self.autosave_now()

        if self.autosave_job:
            try:
                self.root.after_cancel(self.autosave_job)
            except Exception:
                pass

        self.root.destroy()

    def save_current_session_to_db(self):
        """Сохранить текущие данные занятия, не уничтожая историю диагностик.

        Номер занятия описывает посещение клиента, но НЕ идентифицирует
        отдельную диагностику. Поэтому существующая запись занятия
        обновляется только по полям текущей сессии, а diagnosis_history
        всегда сохраняется.
        """
        client = self.save_client_profile(notify=False)

        if client is None:
            return False

        try:
            number = int(
                self.session_number.get()
            )
        except (TypeError, ValueError):
            number = 1

        self.diagnosis["request"] = (
            self.request_text.get(
                "1.0",
                "end"
            ).strip()
        )

        sessions = client.setdefault(
            "sessions",
            []
        )

        existing = None
        for item in sessions:
            try:
                if int(item.get("number", -1)) == number:
                    existing = item
                    break
            except Exception:
                pass

        if existing is None:
            existing = {
                "number": number,
                "date": datetime.now().isoformat(
                    timespec="seconds"
                ),
                "request": self.diagnosis.get(
                    "request",
                    ""
                ),
                "diagnosis": deepcopy(
                    self.diagnosis
                ),
                "what_done": "",
                "notes": "",
                "attachments": [],
                "diagnosis_history": [],
            }
            sessions.append(existing)
        else:
            # Обновляем только текущие данные занятия.
            # diagnosis_history НЕ трогаем.
            existing["request"] = self.diagnosis.get(
                "request",
                ""
            )
            existing["diagnosis"] = deepcopy(
                self.diagnosis
            )
            existing.setdefault(
                "diagnosis_history",
                []
            )
            existing.setdefault(
                "what_done",
                ""
            )
            existing.setdefault(
                "notes",
                ""
            )
            existing.setdefault(
                "attachments",
                []
            )

        sessions.sort(
            key=lambda item: int(
                item.get("number", 0)
            )
        )

        self.save_clients_db()
        self.current_client_id = client["id"]
        self.session_saved = True

        # Черновик можно удалить только после успешной записи в основную БД.
        self.clear_temp_session()

        return True

    def create_new_client_from_database(self, window=None):
        """Открыть чистую карточку нового клиента.

        Новый клиент НЕ попадает в постоянную БД до нажатия
        «Сохранить карточку». Это исключает пустые строки в базе.
        """
        # Если уже есть несохранённый новый клиент — просто открыть его.
        if getattr(self, "_workspace_is_new_client", False):
            try:
                if (
                    hasattr(self, "client_workspace_window")
                    and self.client_workspace_window.winfo_exists()
                ):
                    self.client_workspace_window.lift()
                    self.client_workspace_window.focus_force()
                    return
            except tk.TclError:
                pass

        client = {
            "id": uuid.uuid4().hex,
            "full_name": "",
            "phone": "",
            "email": "",
            "photo_path": "",
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "notes": "",
            "files": [],
            "diagnosis_queries": [],
            "sessions": [],
        }

        # Только рабочая ссылка — в self.clients пока НЕ добавляем.
        self._new_client_draft = client
        self.current_client_id = client["id"]
        self.current_photo_path = ""
        self.current_session_number = 1
        self.current_query_id = None
        self.session_saved = False
        self._workspace_is_new_client = True

        # Очистить основную панель, но не менять постоянную БД.
        self.client_selector.set("")
        self._set_main_entry(self.client_name, "")
        self._set_main_entry(self.client_phone, "")
        self._set_main_entry(self.client_email, "")
        self.client_gender.set("")
        self.client_country.delete(0, "end")
        self.client_country.insert(0, "РФ")
        self.client_city.delete(0, "end")
        self.client_birth_date.delete(0, "end")
        self._set_main_entry(self.client_age, "")
        self.client_vk.delete(0, "end")
        self.client_telegram.delete(0, "end")
        self.client_max.delete(0, "end")
        self._set_main_spinbox(1)
        self.photo_label.configure(image="", text="Фото", bg="#F1F3F5", fg="#9CA3AF")
        self._client_photo_image = None

        self.open_client_workspace(client_override=client)

    def _refresh_client_database_if_open(self):
        """Обновить открытое окно базы клиентов, если оно существует."""
        try:
            if (
                self.client_database_window is not None
                and self.client_database_window.winfo_exists()
                and self.client_database_refresh is not None
            ):
                self.client_database_refresh()
        except (tk.TclError, AttributeError):
            self.client_database_window = None
            self.client_database_refresh = None

    def open_client_database(self):
        # Если окно уже открыто — не плодим второе.
        try:
            if self.client_database_window is not None and self.client_database_window.winfo_exists():
                self.client_database_window.lift()
                self.client_database_window.focus_force()
                return
        except tk.TclError:
            pass

        window = tk.Toplevel(self.root)
        self.client_database_window = window
        window.title("База клиентов")
        window.geometry("1050x620")
        window.minsize(900, 520)
        window.configure(bg="#EEF1F4")

        tk.Label(
            window,
            text="БАЗА КЛИЕНТОВ",
            bg="#EEF1F4",
            fg="#202124",
            font=("Segoe UI", 15, "bold"),
        ).pack(anchor="w", padx=15, pady=(14, 8))

        body = tk.Frame(window, bg="#EEF1F4")
        body.pack(fill="both", expand=True, padx=15, pady=(0, 10))

        left = tk.Frame(
            body,
            bg="white",
            highlightbackground="#D7DBE0",
            highlightthickness=1,
        )
        left.pack(side="left", fill="both", expand=True)

        right = tk.Frame(
            body,
            bg="white",
            highlightbackground="#D7DBE0",
            highlightthickness=1,
        )
        right.pack(
            side="left",
            fill="both",
            expand=True,
            padx=(8, 0)
        )

        tk.Label(
            left,
            text="КЛИЕНТЫ",
            bg="white",
            fg="#202124",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w", padx=12, pady=(10, 5))

        client_tree = ttk.Treeview(
            left,
            columns=("name", "phone", "sessions"),
            show="headings",
        )
        client_tree.heading("name", text="ФИО")
        client_tree.heading("phone", text="Телефон")
        client_tree.heading("sessions", text="Занятий")
        client_tree.column("name", width=220)
        client_tree.column("phone", width=140)
        client_tree.column("sessions", width=75, anchor="center")
        client_tree.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        for client in self.clients:
            if not client.get("full_name", "").strip():
                continue
            client_tree.insert(
                "",
                "end",
                iid=client.get("id"),
                values=(
                    client.get("full_name", ""),
                    self.normalize_phone(client.get("phone", "")),
                    len(client.get("sessions", [])),
                ),
            )

        tk.Label(
            right,
            text="ИСТОРИЯ КЛИЕНТА",
            bg="white",
            fg="#202124",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w", padx=12, pady=(10, 4))

        selected_label = tk.Label(
            right,
            text="Клиент не выбран",
            bg="white",
            fg="#5B4BA3",
            font=("Segoe UI", 11, "bold"),
        )
        selected_label.pack(anchor="w", padx=12, pady=(0, 8))

        session_tree = ttk.Treeview(
            right,
            columns=("number", "date", "request", "files"),
            show="headings",
        )
        session_tree.heading("number", text="Занятие")
        session_tree.heading("date", text="Дата")
        session_tree.heading("request", text="Запрос")
        session_tree.heading("files", text="Файлов")
        session_tree.column("number", width=70, anchor="center")
        session_tree.column("date", width=130)
        session_tree.column("request", width=280)
        session_tree.column("files", width=60, anchor="center")
        session_tree.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        def selected_client():
            sel = client_tree.selection()
            if not sel:
                return None
            return self._find_client(sel[0])

        def refresh_sessions(_event=None):
            client = selected_client()
            session_tree.delete(*session_tree.get_children())

            if not client:
                selected_label.configure(text="Клиент не выбран")
                return

            selected_label.configure(
                text=client.get("full_name", "")
            )

            sessions = sorted(
                client.get("sessions", []),
                key=lambda s: int(s.get("number", 0))
            )

            for session in sessions:
                session_tree.insert(
                    "",
                    "end",
                    iid=str(session.get("number")),
                    values=(
                        session.get("number", ""),
                        session.get("date", "").replace("T", " ")[:16],
                        session.get("request", ""),
                        len(session.get("attachments", [])),
                    ),
                )

        client_tree.bind(
            "<<TreeviewSelect>>",
            refresh_sessions
        )

        def refresh_client_tree():
            """Перерисовать список клиентов и сохранить текущее выделение."""
            selected_id = None
            try:
                selected = client_tree.selection()
                selected_id = selected[0] if selected else self.current_client_id
            except tk.TclError:
                return

            client_tree.delete(*client_tree.get_children())
            for client in self.clients:
                if not client.get("full_name", "").strip():
                    continue
                client_tree.insert(
                    "", "end", iid=client.get("id"),
                    values=(
                        client.get("full_name", ""),
                        self.normalize_phone(client.get("phone", "")),
                        len(client.get("sessions", [])),
                    ),
                )

            if selected_id and client_tree.exists(selected_id):
                client_tree.selection_set(selected_id)
                client_tree.focus(selected_id)
                refresh_sessions()
            else:
                session_tree.delete(*session_tree.get_children())
                selected_label.configure(text="Клиент не выбран")

        self.client_database_refresh = refresh_client_tree

        def open_selected():
            client = selected_client()
            if not client:
                messagebox.showwarning(
                    "База клиентов",
                    "Сначала выбери клиента."
                )
                return

            session_sel = session_tree.selection()

            if session_sel:
                number = int(session_sel[0])
                session = next(
                    (
                        s for s in client.get("sessions", [])
                        if int(s.get("number", -1)) == number
                    ),
                    None
                )
            else:
                sessions = sorted(
                    client.get("sessions", []),
                    key=lambda s: int(s.get("number", 0))
                )
                session = sessions[-1] if sessions else None
                number = (
                    int(session.get("number", 1))
                    if session else 1
                )

            self.current_client_id = client.get("id")
            self.current_photo_path = client.get("photo_path", "")

            self._set_main_entry(self.client_name, client.get("full_name", ""))
            self._set_main_entry(
                self.client_phone,
                self.normalize_phone(client.get("phone", ""))
            )
            self._set_main_entry(self.client_email, client.get("email", ""))

            self.show_client_photo(self.current_photo_path)

            if session:
                self.current_session_number = number
                self._set_main_spinbox(number)
                self.load_session_into_editor(client, session)
            else:
                self.current_session_number = 1
                self._set_main_spinbox(1)
                self.diagnosis = new_diagnosis()
                self.request_text.delete("1.0", "end")
                self.refresh_situations()
                self.clear_editor()
                self.hide_instinct()
                self.hide_result()

            window.destroy()

        def new_session():
            client = selected_client()
            if not client:
                messagebox.showwarning(
                    "База клиентов",
                    "Сначала выбери клиента."
                )
                return

            self.autosave_now()

            self.current_client_id = client.get("id")
            self.current_photo_path = client.get("photo_path", "")

            self._set_main_entry(self.client_name, client.get("full_name", ""))
            self._set_main_entry(
                self.client_phone,
                self.normalize_phone(client.get("phone", ""))
            )
            self._set_main_entry(self.client_email, client.get("email", ""))

            self.show_client_photo(self.current_photo_path)

            numbers = [
                int(s.get("number", 0))
                for s in client.get("sessions", [])
                if str(s.get("number", "")).isdigit()
            ]
            next_number = max(numbers) + 1 if numbers else 1

            self.current_session_number = next_number
            self._set_main_spinbox(next_number)
            self.diagnosis = new_diagnosis()
            self.request_text.delete("1.0", "end")
            self.selected_situation = None
            self.selected_element = None
            self.refresh_situations()
            self.clear_editor()
            self.hide_instinct()
            self.hide_result()

            window.destroy()

        def edit_selected_client():
            client = selected_client()
            if not client:
                messagebox.showwarning("База клиентов", "Сначала выбери клиента.")
                return
            self.current_client_id = client.get("id")
            self.current_photo_path = client.get("photo_path", "")
            self._workspace_is_new_client = False
            self.open_client_workspace(client_override=client)

        def delete_selected_client():
            client = selected_client()
            if not client:
                messagebox.showwarning("База клиентов", "Сначала выбери клиента.")
                return

            name = client.get("full_name", "Без имени")
            if not messagebox.askyesno(
                "Удалить клиента",
                f"Удалить клиента «{name}» полностью?\n\n"
                "Будут удалены его данные из базы, история занятий и записи.\n"
                "Это действие нельзя отменить.",
                parent=window,
            ):
                return

            try:
                folder = self.client_folder(client)
                if folder.exists():
                    shutil.rmtree(folder, ignore_errors=True)
            except Exception:
                pass

            self.clients = [
                item for item in self.clients
                if item.get("id") != client.get("id")
            ]
            if self.current_client_id == client.get("id"):
                self.current_client_id = None
                self.current_photo_path = ""
                self._set_main_entry(self.client_name, "")
                self._set_main_entry(self.client_phone, "")
                self._set_main_entry(self.client_email, "")
                self._set_main_spinbox(1)
                self.photo_label.configure(image="", text="Фото", bg="#F1F3F5", fg="#9CA3AF")
                self._client_photo_image = None

            self.save_clients_db()
            self.refresh_client_selector()
            refresh_client_tree()

        def close_database():
            try:
                window.destroy()
            finally:
                self.client_database_window = None
                self.client_database_refresh = None

        window.protocol("WM_DELETE_WINDOW", close_database)

        buttons = tk.Frame(window, bg="#EEF1F4")
        buttons.pack(fill="x", padx=15, pady=(0, 12))

        self.button(
            buttons,
            "Новый клиент",
            lambda: self.create_new_client_from_database(window),
            primary=True,
        ).pack(side="left")

        self.button(
            buttons,
            "Редактировать клиента",
            edit_selected_client,
        ).pack(side="left", padx=6)

        self.button(
            buttons,
            "Удалить клиента",
            delete_selected_client,
        ).pack(side="left", padx=6)

        self.button(
            buttons,
            "Открыть занятие",
            open_selected,
        ).pack(side="left", padx=6)

        self.button(
            buttons,
            "Новое занятие",
            new_session,
        ).pack(side="left", padx=6)

        self.button(
            buttons,
            "Закрыть",
            close_database,
        ).pack(side="right")

        if self.clients:
            first_id = self.clients[0].get("id")
            client_tree.selection_set(first_id)
            client_tree.focus(first_id)
            refresh_sessions()

    # ======================================================
    # МАТЕРИАЛЫ, ЗАМЕТКИ И ИСТОРИЯ КЛИЕНТА
    # ======================================================

    def open_client_materials(self):
        client = self._find_client(
            self.current_client_id
        )

        if client is None:
            name = self.client_name.get().strip()

            if not name:
                messagebox.showwarning(
                    "Клиент",
                    "Сначала создай или выбери клиента."
                )
                return

            client = self.save_client_profile(
                notify=False
            )

        if client is None:
            return

        window = tk.Toplevel(
            self.root
        )
        window.title(
            f"Карточка клиента — "
            f"{client.get('full_name', '')}"
        )
        window.geometry(
            "950x680"
        )
        window.minsize(
            800,
            560
        )
        window.configure(
            bg="#EEF1F4"
        )

        header = tk.Frame(
            window,
            bg="#EEF1F4"
        )
        header.pack(
            fill="x",
            padx=16,
            pady=(12, 8)
        )

        tk.Label(
            header,
            text=client.get(
                "full_name",
                ""
            ),
            bg="#EEF1F4",
            fg="#202124",
            font=(
                "Segoe UI",
                16,
                "bold"
            ),
        ).pack(
            side="left"
        )

        notebook = ttk.Notebook(
            window
        )
        notebook.pack(
            fill="both",
            expand=True,
            padx=16,
            pady=(0, 12)
        )

        # --------------------------------------------------
        # ВКЛАДКА 1 — КЛИЕНТ
        # --------------------------------------------------
        client_tab = tk.Frame(
            notebook,
            bg="white"
        )
        notebook.add(
            client_tab,
            text="Клиент"
        )

        tk.Label(
            client_tab,
            text="ЛИЧНЫЕ ЗАМЕТКИ",
            bg="white",
            fg="#202124",
            font=(
                "Segoe UI",
                10,
                "bold"
            ),
        ).pack(
            anchor="w",
            padx=15,
            pady=(15, 5)
        )

        client_notes = tk.Text(
            client_tab,
            height=10,
            wrap="word",
            font=(
                "Segoe UI",
                10
            ),
        )
        client_notes.pack(
            fill="both",
            expand=False,
            padx=15
        )
        client_notes.insert(
            "1.0",
            client.get(
                "notes",
                ""
            )
        )

        tk.Label(
            client_tab,
            text="ФАЙЛЫ КЛИЕНТА",
            bg="white",
            fg="#202124",
            font=(
                "Segoe UI",
                10,
                "bold"
            ),
        ).pack(
            anchor="w",
            padx=15,
            pady=(15, 5)
        )

        client_files = tk.Listbox(
            client_tab,
            height=7,
            font=(
                "Segoe UI",
                9
            ),
        )
        client_files.pack(
            fill="both",
            expand=True,
            padx=15
        )

        def refresh_client_files():
            client_files.delete(
                0,
                "end"
            )
            for item in client.get(
                "files",
                []
            ):
                client_files.insert(
                    "end",
                    Path(
                        item
                    ).name
                )

        def add_client_file():
            paths = filedialog.askopenfilenames(
                title="Добавить файл клиента"
            )

            if not paths:
                return

            folder = (
                self.client_folder(
                    client
                )
                / "files"
            )

            for source_name in paths:
                source = Path(
                    source_name
                )
                target = (
                    folder
                    / f"{uuid.uuid4().hex}"
                    f"_{source.name}"
                )

                try:
                    shutil.copy2(
                        source,
                        target
                    )
                    client.setdefault(
                        "files",
                        []
                    ).append(
                        str(target)
                    )
                except Exception as exc:
                    messagebox.showerror(
                        "Файл",
                        f"Не удалось добавить "
                        f"{source.name}:\n{exc}"
                    )

            self.save_clients_db()
            refresh_client_files()

        def save_client_notes():
            client["notes"] = (
                client_notes.get(
                    "1.0",
                    "end"
                ).strip()
            )
            self.save_clients_db()

            messagebox.showinfo(
                "Клиент",
                "Данные клиента сохранены."
            )

        client_buttons = tk.Frame(
            client_tab,
            bg="white"
        )
        client_buttons.pack(
            fill="x",
            padx=15,
            pady=10
        )

        self.button(
            client_buttons,
            "Сохранить заметки",
            save_client_notes,
            primary=True
        ).pack(
            side="left"
        )

        self.button(
            client_buttons,
            "+ Добавить файл",
            add_client_file
        ).pack(
            side="left",
            padx=6
        )

        refresh_client_files()

        # --------------------------------------------------
        # ВКЛАДКА 2 — ТЕКУЩАЯ СЕССИЯ
        # --------------------------------------------------
        session_tab = tk.Frame(
            notebook,
            bg="white"
        )
        notebook.add(
            session_tab,
            text=(
                f"Занятие №"
                f"{self.session_number.get()}"
            )
        )

        session_number_value = (
            self.session_number.get()
        )

        tk.Label(
            session_tab,
            text=(
                f"ЗАНЯТИЕ № "
                f"{session_number_value}"
            ),
            bg="white",
            fg="#202124",
            font=(
                "Segoe UI",
                10,
                "bold"
            ),
        ).pack(
            anchor="w",
            padx=15,
            pady=(15, 5)
        )

        tk.Label(
            session_tab,
            text="ЧТО БЫЛО СДЕЛАНО НА СЕССИИ",
            bg="white",
            fg="#202124",
            font=(
                "Segoe UI",
                10,
                "bold"
            ),
        ).pack(
            anchor="w",
            padx=15,
            pady=(8, 4)
        )

        what_done = tk.Text(
            session_tab,
            height=7,
            wrap="word",
            font=(
                "Segoe UI",
                10
            ),
        )
        what_done.pack(
            fill="x",
            padx=15
        )

        tk.Label(
            session_tab,
            text="ЗАМЕТКИ СПЕЦИАЛИСТА",
            bg="white",
            fg="#202124",
            font=(
                "Segoe UI",
                10,
                "bold"
            ),
        ).pack(
            anchor="w",
            padx=15,
            pady=(10, 4)
        )

        session_notes = tk.Text(
            session_tab,
            height=7,
            wrap="word",
            font=(
                "Segoe UI",
                10
            ),
        )
        session_notes.pack(
            fill="x",
            padx=15
        )

        # Ищем текущую запись занятия.
        current_number = int(
            session_number_value
        )

        current_session = None
        for item in client.get(
            "sessions",
            []
        ):
            try:
                if int(
                    item.get(
                        "number",
                        -1
                    )
                ) == current_number:
                    current_session = item
                    break
            except Exception:
                pass

        if current_session:
            what_done.insert(
                "1.0",
                current_session.get(
                    "what_done",
                    ""
                )
            )
            session_notes.insert(
                "1.0",
                current_session.get(
                    "notes",
                    ""
                )
            )

        tk.Label(
            session_tab,
            text="АУДИО / ВИДЕО / ФАЙЛЫ СЕССИИ",
            bg="white",
            fg="#202124",
            font=(
                "Segoe UI",
                10,
                "bold"
            ),
        ).pack(
            anchor="w",
            padx=15,
            pady=(10, 4)
        )

        session_files = tk.Listbox(
            session_tab,
            height=5,
            font=(
                "Segoe UI",
                9
            ),
        )
        session_files.pack(
            fill="both",
            expand=True,
            padx=15
        )

        def get_session_record():
            for item in client.get(
                "sessions",
                []
            ):
                try:
                    if int(
                        item.get(
                            "number",
                            -1
                        )
                    ) == current_number:
                        return item
                except Exception:
                    pass

            record = {
                "number": current_number,
                "date": datetime.now().isoformat(
                    timespec="seconds"
                ),
                "request": self.diagnosis.get(
                    "request",
                    ""
                ),
                "diagnosis": deepcopy(
                    self.diagnosis
                ),
                "what_done": "",
                "notes": "",
                "attachments": [],
            }

            client.setdefault(
                "sessions",
                []
            ).append(
                record
            )

            return record

        def refresh_session_files():
            session_files.delete(
                0,
                "end"
            )

            record = get_session_record()

            for item in record.get(
                "attachments",
                []
            ):
                session_files.insert(
                    "end",
                    Path(
                        self.absolute_data_path(
                            item
                        )
                    ).name
                )

        def add_session_files():
            paths = filedialog.askopenfilenames(
                title=(
                    "Добавить аудио, видео "
                    "или файл к занятию"
                ),
                filetypes=[
                    (
                        "Аудио",
                        "*.mp3 *.wav *.m4a *.aac *.ogg *.flac"
                    ),
                    (
                        "Видео",
                        "*.mp4 *.mov *.avi *.mkv *.webm *.mpeg *.mpg"
                    ),
                    (
                        "Все файлы",
                        "*.*"
                    ),
                ],
            )

            if not paths:
                return

            record = get_session_record()

            folder = (
                self.session_folder(
                    client,
                    current_number
                )
                / "files"
            )

            for source_name in paths:
                source = Path(
                    source_name
                )

                target = (
                    folder
                    / f"{uuid.uuid4().hex}"
                    f"_{source.name}"
                )

                try:
                    shutil.copy2(
                        source,
                        target
                    )
                    record.setdefault(
                        "attachments",
                        []
                    ).append(
                        str(target)
                    )
                except Exception as exc:
                    messagebox.showerror(
                        "Файл",
                        f"Не удалось добавить "
                        f"{source.name}:\n{exc}"
                    )

            self.save_clients_db()
            refresh_session_files()

        def save_session_notes():
            record = get_session_record()

            record["what_done"] = (
                what_done.get(
                    "1.0",
                    "end"
                ).strip()
            )
            record["notes"] = (
                session_notes.get(
                    "1.0",
                    "end"
                ).strip()
            )
            record["diagnosis"] = deepcopy(
                self.diagnosis
            )
            record["request"] = self.request_text.get(
                "1.0",
                "end"
            ).strip()

            self.save_clients_db()

            messagebox.showinfo(
                "Сессия",
                f"Занятие №{current_number} сохранено."
            )

        session_buttons = tk.Frame(
            session_tab,
            bg="white"
        )
        session_buttons.pack(
            fill="x",
            padx=15,
            pady=10
        )

        self.button(
            session_buttons,
            "Сохранить данные сессии",
            save_session_notes,
            primary=True
        ).pack(
            side="left"
        )

        self.button(
            session_buttons,
            "+ Аудио / видео / файл",
            add_session_files
        ).pack(
            side="left",
            padx=6
        )

        refresh_session_files()

        # --------------------------------------------------
        # ВКЛАДКА 3 — ИСТОРИЯ ПОСЕЩЕНИЙ
        # --------------------------------------------------
        history_tab = tk.Frame(
            notebook,
            bg="white"
        )
        notebook.add(
            history_tab,
            text="История посещений"
        )

        history = ttk.Treeview(
            history_tab,
            columns=(
                "number",
                "date",
                "request",
                "files",
            ),
            show="headings"
        )

        history.heading(
            "number",
            text="Занятие"
        )
        history.heading(
            "date",
            text="Дата"
        )
        history.heading(
            "request",
            text="Запрос"
        )
        history.heading(
            "files",
            text="Файлов"
        )

        history.column(
            "number",
            width=80,
            anchor="center"
        )
        history.column(
            "date",
            width=150
        )
        history.column(
            "request",
            width=440
        )
        history.column(
            "files",
            width=80,
            anchor="center"
        )

        history.pack(
            fill="both",
            expand=True,
            padx=15,
            pady=15
        )

        for item in sorted(
            client.get(
                "sessions",
                []
            ),
            key=lambda x: int(
                x.get(
                    "number",
                    0
                )
            )
        ):
            history.insert(
                "",
                "end",
                values=(
                    item.get(
                        "number",
                        ""
                    ),
                    item.get(
                        "date",
                        ""
                    ).replace(
                        "T",
                        " "
                    )[:16],
                    item.get(
                        "request",
                        ""
                    ),
                    len(
                        item.get(
                            "attachments",
                            []
                        )
                    ),
                )
            )

        tk.Label(
            history_tab,
            text=(
                "История хранится отдельно от текущего "
                "занятия. Старые записи не перезаписываются."
            ),
            bg="white",
            fg="#6B7280",
            font=(
                "Segoe UI",
                9
            ),
        ).pack(
            anchor="w",
            padx=15,
            pady=(0, 10)
        )

        def save_all_and_close():
            client["notes"] = (
                client_notes.get(
                    "1.0",
                    "end"
                ).strip()
            )

            record = get_session_record()

            record["what_done"] = (
                what_done.get(
                    "1.0",
                    "end"
                ).strip()
            )
            record["notes"] = (
                session_notes.get(
                    "1.0",
                    "end"
                ).strip()
            )
            record["diagnosis"] = deepcopy(
                self.diagnosis
            )
            record["request"] = self.request_text.get(
                "1.0",
                "end"
            ).strip()

            self.save_clients_db()
            window.destroy()

        self.button(
            window,
            "Сохранить всё и закрыть",
            save_all_and_close,
            primary=True
        ).pack(
            anchor="e",
            padx=16,
            pady=(0, 12)
        )

    # ======================================================
    # СИТУАЦИИ
    # ======================================================

    def refresh_situations(self):

        self.situation_list.delete(0, "end")

        for index, situation in enumerate(
            self.diagnosis["situations"]
        ):
            bg, fg = self.situation_colors(index)

            self.situation_list.insert(
                "end",
                f'{situation["name"]}   '
                f'[{situation["level"]}/10]'
            )

            # Каждая ситуация получает свой цвет прямо в списке.
            # При выборе цвет становится чуть насыщеннее, но
            # сохраняет принадлежность к этой ситуации.
            self.situation_list.itemconfigure(
                index,
                background=bg,
                foreground=fg,
                selectbackground=fg,
                selectforeground="white",
            )

    def add_situation(self):

        dialog = TextDialog(
            self.root,
            "Добавить ситуацию",
            "Название ситуации",
        )
        self.root.wait_window(dialog)

        if not dialog.result:
            return

        level = LevelDialog(
            self.root,
            "Дискомфорт ситуации",
        )
        self.root.wait_window(level)

        if level.result is None:
            return

        add_situation(
            self.diagnosis,
            dialog.result,
            level.result,
        )

        self.refresh_situations()
        self.select_last_situation()

    def select_last_situation(self):

        count = len(
            self.diagnosis["situations"]
        )

        if count == 0:
            return

        self.situation_list.selection_clear(
            0, "end"
        )
        self.situation_list.selection_set(
            count - 1
        )
        self.situation_list.see(
            count - 1
        )
        self.on_situation_select()

    def on_situation_select(self, _event=None):

        selection = (
            self.situation_list.curselection()
        )

        if not selection:
            return

        self.selected_situation = selection[0]

        situation = (
            self.diagnosis["situations"][
                self.selected_situation
            ]
        )

        situation_bg, situation_fg = self.situation_colors(
            self.selected_situation
        )

        self.situation_title.config(
            text=situation["name"],
            bg=situation_bg,
            fg=situation_fg,
            padx=10,
            pady=5,
        )

        self.situation_info.config(
            text=f'Дискомфорт: {situation["level"]}/10'
        )

        self.refresh_tree()

        # Результат относится только к ситуации.
        # Инстинкт относится только к убеждению 2.
        self.hide_instinct()
        self.refresh_result()
        self.show_result()

    def edit_situation(self):

        if self.selected_situation is None:
            return

        situation = (
            self.diagnosis["situations"][
                self.selected_situation
            ]
        )

        dialog = TextDialog(
            self.root,
            "Изменить ситуацию",
            "Название ситуации",
            situation.get("name", ""),
        )
        self.root.wait_window(dialog)

        if dialog.result is not None:
            situation["name"] = dialog.result

        level = LevelDialog(
            self.root,
            "Дискомфорт ситуации",
            initial=situation.get("level", 5),
        )
        self.root.wait_window(level)

        if level.result is not None:
            situation["level"] = level.result

        comment = TextDialog(
            self.root,
            "Комментарий ситуации",
            "Комментарий / уточнение",
            situation.get("comment", ""),
        )
        self.root.wait_window(comment)

        if comment.result is not None:
            situation["comment"] = comment.result

        self.refresh_situations()
        self.on_situation_select()

    def delete_situation(self):

        if self.selected_situation is None:
            return

        if not messagebox.askyesno(
            "Удаление",
            "Удалить ситуацию вместе со всем содержимым?"
        ):
            return

        del self.diagnosis["situations"][
            self.selected_situation
        ]

        self.selected_situation = None
        self.refresh_situations()

        self.tree.delete(
            *self.tree.get_children()
        )

        self.situation_title.config(
            text="Выберите ситуацию"
        )
        self.situation_info.config(text="")
        self.clear_editor()

    # ======================================================
    # ДЕРЕВО
    # ======================================================

    def refresh_tree(self):

        self.tree.delete(
            *self.tree.get_children()
        )

        situation = self.current_situation()

        if situation is None:
            return

        for b, belief in enumerate(
            situation.get("beliefs", [])
        ):

            belief_id = f"b:{b}"

            self.tree.insert(
                "",
                "end",
                iid=belief_id,
                text=(
                    f'Убеждение {b + 1}: {belief.get("text", "")} '
                    f'({belief.get("level", 5)}/10)'
                ),
                open=True,
                tags=("primary",),
            )

            for f, feeling in enumerate(
                belief.get("feelings", [])
            ):

                feeling_id = f"f:{b}:{f}"

                self.tree.insert(
                    belief_id,
                    "end",
                    iid=feeling_id,
                    text=(
                        f'☑ {feeling.get("text", "")} '
                        f'({feeling.get("level", 5)}/10)'
                    ),
                    open=True,
                    tags=("feeling",),
                )

                for d, deep in enumerate(
                    feeling.get("deep", [])
                ):

                    deep_id = f"d:{b}:{f}:{d}"

                    self.tree.insert(
                        feeling_id,
                        "end",
                        iid=deep_id,
                        text=(
                            f'Убеждение 2: '
                            f'{deep.get("text", "")} '
                            f'({deep.get("level", 5)}/10)'
                        ),
                        open=True,
                        tags=("deep",),
                    )

                    instincts = self.get_instincts(deep)

                    for k, instinct in enumerate(instincts):

                        instinct_id = f"i:{b}:{f}:{d}:{k}"

                        name = instinct.get("name", "")
                        if not name:
                            name = "Не выбран"

                        self.tree.insert(
                            deep_id,
                            "end",
                            iid=instinct_id,
                            text=(
                                f'Инстинкт {k + 1}: '
                                f'{name} '
                                f'({instinct.get("level", 5)}/10)'
                            ),
                            tags=("instinct",),
                        )

    # ======================================================
    # УБЕЖДЕНИЕ 1
    # ======================================================

    def add_belief1(self):

        situation = self.current_situation()

        if situation is None:
            messagebox.showinfo(
                "Диагностика",
                "Сначала выбери ситуацию."
            )
            return

        dialog = TextDialog(
            self.root,
            "Ограничивающее убеждение 1",
            "Что клиент говорит о себе?"
        )
        self.root.wait_window(dialog)

        if not dialog.result:
            return

        level = LevelDialog(
            self.root,
            "Уровень убеждения 1"
        )
        self.root.wait_window(level)

        if level.result is None:
            return

        add_belief1(
            situation,
            dialog.result,
            level.result
        )

        self.refresh_tree()

    # ======================================================
    # ВТОРИЧНЫЕ ЧУВСТВА — ГАЛОЧКИ
    # ======================================================

    def add_feeling(self):

        selected = self.get_selected_path()

        if not selected:
            messagebox.showinfo(
                "Диагностика",
                "Сначала выбери убеждение 1."
            )
            return

        if selected[0] != "belief":
            messagebox.showinfo(
                "Диагностика",
                "Вторичные чувства добавляются к убеждению 1."
            )
            return

        dialog = SecondaryFeelingsDialog(
            self.root,
            selected[2]
        )
        self.root.wait_window(dialog)

        if not dialog.result:
            return

        belief = selected[2]

        # Синхронизируем список: выбранные добавляются,
        # снятые удаляются.
        existing = {
            item.get("text", ""): item
            for item in belief.get("feelings", [])
        }

        selected_names = {
            item["name"]
            for item in dialog.result
        }

        belief["feelings"] = [
            item
            for item in belief.get("feelings", [])
            if item.get("text", "") in selected_names
        ]

        existing_after = {
            item.get("text", ""): item
            for item in belief["feelings"]
        }

        for item in dialog.result:

            if item["name"] in existing_after:

                feeling = existing_after[
                    item["name"]
                ]

                feeling["level"] = item["level"]
                feeling["comment"] = item["comment"]

            else:

                add_feeling(
                    belief,
                    item["name"],
                    item["level"],
                    item["comment"],
                )

        self.refresh_tree()

    # ======================================================
    # УБЕЖДЕНИЕ 2
    # ======================================================

    def add_belief2(self):

        selected = self.get_selected_path()

        if not selected:
            return

        if selected[0] != "feeling":
            messagebox.showinfo(
                "Диагностика",
                "Сначала выбери вторичное чувство."
            )
            return

        dialog = TextDialog(
            self.root,
            "Ограничивающее убеждение 2",
            "Какая глубинная мысль стоит за этим чувством?"
        )
        self.root.wait_window(dialog)

        if not dialog.result:
            return

        level = LevelDialog(
            self.root,
            "Уровень убеждения 2"
        )
        self.root.wait_window(level)

        if level.result is None:
            return

        add_belief2(
            selected[3],
            dialog.result,
            level.result
        )

        self.refresh_tree()

    # ======================================================
    # ВЫБОР ЭЛЕМЕНТА
    # ======================================================

    def highlight_selected_tree_item(self):
        """Выделяет текущую строку поверх её базового цвета."""
        selected = self.tree.selection()

        for root_item in self.tree.get_children(""):
            self._remove_active_tag_recursive(root_item)

        if not selected:
            return

        item_id = selected[0]
        tags = list(self.tree.item(item_id, "tags"))

        if "active_selection" not in tags:
            tags.append("active_selection")

        self.tree.item(
            item_id,
            tags=tuple(tags),
        )

        # Не прокручиваем дерево автоматически.
        # При выборе инстинкта это создавало резкий скачок
        # вертикального положения и ощущение, что дерево "смещается".

    def _remove_active_tag_recursive(self, item_id):
        tags = [
            tag
            for tag in self.tree.item(item_id, "tags")
            if tag != "active_selection"
        ]

        self.tree.item(
            item_id,
            tags=tuple(tags),
        )

        for child in self.tree.get_children(item_id):
            self._remove_active_tag_recursive(child)

    def on_element_select(self, _event=None):

        self.highlight_selected_tree_item()

        self.hide_result()

        selected = self.get_selected_path()

        if not selected:
            self.clear_editor()
            return

        if selected[0] == "belief":

            element = selected[2]
            self.show_element_editor()
            self.element_title.config(
                text="Ограничивающее убеждение 1"
            )
            self.selected_element = ("belief", element)
            self.load_editor(element)
            self.clear_instinct()
            self.hide_instinct()
            return

        if selected[0] == "feeling":

            element = selected[3]
            self.show_element_editor()
            self.element_title.config(
                text="Вторичное чувство"
            )
            self.selected_element = ("feeling", element)
            self.load_editor(element)
            self.clear_instinct()
            self.hide_instinct()
            return

        if selected[0] == "deep":

            element = selected[4]
            self.show_element_editor()
            self.element_title.config(
                text="Ограничивающее убеждение 2"
            )
            self.selected_element = ("deep", element)
            self.load_editor(element)
            self.selected_instinct_index = 0
            self.load_instinct_by_index(element, 0)
            self.show_instinct()
            return

        if selected[0] == "instinct":

            deep = selected[5]
            instinct_index = selected[4]

            self.selected_element = ("instinct", selected[6], deep)
            self.selected_instinct_index = instinct_index
            self.hide_element_editor()
            self.load_instinct_by_index(deep, instinct_index)
            self.show_instinct()
            return

        self.clear_editor()

    def get_selected_path(self):

        selection = self.tree.selection()

        if not selection:
            return None

        parts = selection[0].split(":")
        situation = self.current_situation()

        if situation is None:
            return None

        if parts[0] == "b":
            b = int(parts[1])
            return (
                "belief",
                b,
                situation["beliefs"][b],
            )

        if parts[0] == "f":
            b = int(parts[1])
            f = int(parts[2])
            belief = situation["beliefs"][b]
            return (
                "feeling",
                b,
                belief,
                belief["feelings"][f],
            )

        if parts[0] == "d":
            b = int(parts[1])
            f = int(parts[2])
            d = int(parts[3])
            belief = situation["beliefs"][b]
            feeling = belief["feelings"][f]
            return (
                "deep",
                b,
                belief,
                feeling,
                feeling["deep"][d],
            )

        if parts[0] == "i":
            b = int(parts[1])
            f = int(parts[2])
            d = int(parts[3])
            k = int(parts[4])
            belief = situation["beliefs"][b]
            feeling = belief["feelings"][f]
            deep = feeling["deep"][d]
            instincts = self.get_instincts(deep)
            return (
                "instinct",
                b,
                belief,
                feeling,
                k,
                deep,
                instincts[k],
            )

        return None

    # ======================================================
    # РЕДАКТОР
    # ======================================================

    def load_editor(self, element):

        self.element_text.delete(
            "1.0",
            "end"
        )
        self.element_text.insert(
            "1.0",
            element.get("text", "")
        )

        self.element_level.set(
            element.get("level", 5)
        )

        self.element_comment.delete(
            "1.0",
            "end"
        )
        self.element_comment.insert(
            "1.0",
            element.get("comment", "")
        )

    def save_element(self):

        if not self.selected_element:
            return

        if self.selected_element[0] == "instinct":
            self.save_instinct()
            return

        element = self.selected_element[1]

        element["text"] = (
            self.element_text
            .get("1.0", "end")
            .strip()
        )

        element["comment"] = (
            self.element_comment
            .get("1.0", "end")
            .strip()
        )

        try:
            level = int(
                self.element_level.get()
            )
        except ValueError:
            level = 5

        element["level"] = max(
            1,
            min(10, level)
        )

        self.refresh_tree()

    def clear_editor(self):

        self.selected_element = None

        self.element_title.config(
            text="Элемент не выбран"
        )

        self.element_text.delete(
            "1.0",
            "end"
        )

        self.element_comment.delete(
            "1.0",
            "end"
        )

        self.element_level.set("5")

        self.clear_instinct()
        self.hide_instinct()
        self.show_element_editor()

    # ======================================================
    # ИНСТИНКТ(Ы)
    # ======================================================

    def get_instincts(self, deep):
        """Возвращает список инстинктов и мигрирует старый формат."""
        instincts = deep.get("instincts")

        if isinstance(instincts, list) and instincts:
            return instincts

        old = deep.get("instinct")
        if isinstance(old, dict):
            migrated = {
                "name": old.get("name", ""),
                "level": old.get("level", 5),
                "comment": old.get("comment", ""),
            }
        else:
            migrated = {
                "name": "",
                "level": 5,
                "comment": "",
            }

        deep["instincts"] = [migrated]
        return deep["instincts"]

    def load_instinct_by_index(self, deep, index=0):

        instincts = self.get_instincts(deep)

        while len(instincts) <= index:
            instincts.append({
                "name": "",
                "level": 5,
                "comment": "",
            })

        instinct = instincts[index]

        self.instinct_selected_label.config(
            text=f"Инстинкт {index + 1}"
        )

        self.instinct_combo.set(
            instinct.get("name", "")
        )

        self.instinct_level.set(
            instinct.get("level", 5)
        )

        self.instinct_comment.delete(
            0,
            "end"
        )
        self.instinct_comment.insert(
            0,
            instinct.get("comment", "")
        )

    def clear_instinct(self):

        self.selected_instinct_index = 0
        self.instinct_selected_label.config(
            text="Инстинкт 1"
        )
        self.instinct_combo.set("")
        self.instinct_level.set("5")
        self.instinct_comment.delete(
            0,
            "end"
        )

    def show_instinct(self):
        if self.instinct_frame.winfo_manager() != "pack":
            self.instinct_frame.pack(
                fill="x",
                padx=15,
                pady=(0, 10),
            )

    def hide_instinct(self):
        self.instinct_frame.pack_forget()

    def hide_element_editor(self):
        self.element_editor_frame.pack_forget()

    def show_element_editor(self):
        if self.element_editor_frame.winfo_manager() != "pack":
            self.element_editor_frame.pack(
                fill="x",
            )

    def add_instinct(self):

        deep = None

        if self.selected_element:
            if self.selected_element[0] == "deep":
                deep = self.selected_element[1]
            elif self.selected_element[0] == "instinct":
                deep = self.selected_element[2]

        if deep is None:
            messagebox.showinfo(
                "Инстинкт",
                "Инстинкты можно добавлять только к убеждению 2."
            )
            return

        new_item = add_instinct(deep)
        instincts = self.get_instincts(deep)
        self.selected_instinct_index = len(instincts) - 1

        self.selected_element = (
            "instinct",
            new_item,
            deep,
        )

        self.refresh_tree()
        self.load_instinct_by_index(
            deep,
            self.selected_instinct_index,
        )
        self.hide_element_editor()
        self.show_instinct()

        # Выделяем добавленный инстинкт в дереве.
        iid = None
        selection = self.tree.selection()
        if selection:
            # Не меняем текущую ситуацию, только ищем нужную ветку.
            pass

    def save_instinct(self):

        deep = None
        index = getattr(self, "selected_instinct_index", 0)

        if self.selected_element:
            if self.selected_element[0] == "deep":
                deep = self.selected_element[1]
            elif self.selected_element[0] == "instinct":
                deep = self.selected_element[2]

        if deep is None:
            messagebox.showinfo(
                "Инстинкт",
                "Инстинкт существует только у убеждения 2."
            )
            return

        instincts = self.get_instincts(deep)
        while len(instincts) <= index:
            instincts.append({
                "name": "",
                "level": 5,
                "comment": "",
            })

        name = self.instinct_combo.get().strip()

        if not name:
            messagebox.showwarning(
                "Инстинкт",
                "Выбери тип инстинкта."
            )
            return

        try:
            level = int(self.instinct_level.get())
        except ValueError:
            level = 5

        level = max(1, min(10, level))

        instincts[index]["name"] = name
        instincts[index]["level"] = level
        instincts[index]["comment"] = self.instinct_comment.get().strip()

        # Сохраняем старое поле для обратной совместимости.
        if index == 0:
            deep["instinct"] = dict(instincts[0])

        self.refresh_tree()

    # ======================================================
    # РЕЗУЛЬТАТ

    # ======================================================

    def show_result(self):
        if not self.result_label.winfo_ismapped():
            self.result_label.pack(
                anchor="w",
                padx=15,
                pady=(3, 0),
            )
        if not self.result_text.winfo_ismapped():
            self.result_text.pack(
                fill="x",
                padx=15,
                pady=6,
            )
        if not self.result_button.winfo_ismapped():
            self.result_button.pack(
                anchor="w",
                padx=15,
                pady=(0, 10),
            )

    def hide_result(self):
        if hasattr(self, "result_label"):
            self.result_label.pack_forget()
        if hasattr(self, "result_text"):
            self.result_text.pack_forget()
        if hasattr(self, "result_button"):
            self.result_button.pack_forget()

    def refresh_result(self):

        situation = self.current_situation()

        self.result_text.delete(
            "1.0",
            "end"
        )

        if situation:
            self.result_text.insert(
                "1.0",
                situation.get("result", "")
            )

    def save_result(self):

        situation = self.current_situation()

        if situation is None:
            return

        result = (
            self.result_text
            .get("1.0", "end")
            .strip()
        )

        set_result(
            situation,
            result
        )

    # ======================================================
    # УДАЛЕНИЕ
    # ======================================================

    def delete_element(self):

        selected = self.get_selected_path()

        if not selected:
            return

        if not messagebox.askyesno(
            "Удаление",
            "Удалить выбранный элемент?"
        ):
            return

        indexes = self.get_selected_indexes()
        situation = self.current_situation()

        if selected[0] == "belief":

            del situation["beliefs"][
                indexes[0]
            ]

        elif selected[0] == "feeling":

            belief = selected[2]

            del belief["feelings"][
                indexes[1]
            ]

        elif selected[0] == "deep":

            feeling = selected[3]

            del feeling["deep"][
                indexes[2]
            ]

        elif selected[0] == "instinct":

            deep = selected[5]
            instinct_index = selected[4]
            instincts = self.get_instincts(deep)

            if len(instincts) <= 1:
                # Первый инстинкт не удаляем: он является полем по умолчанию.
                instincts[0] = {
                    "name": "",
                    "level": 5,
                    "comment": "",
                }
            else:
                del instincts[instinct_index]

        self.clear_editor()
        self.refresh_tree()

    def get_selected_indexes(self):

        selection = self.tree.selection()

        if not selection:
            return None, None, None

        parts = selection[0].split(":")

        if parts[0] == "b":
            return (
                int(parts[1]),
                None,
                None,
            )

        if parts[0] == "f":
            return (
                int(parts[1]),
                int(parts[2]),
                None,
            )

        if parts[0] == "d":
            return (
                int(parts[1]),
                int(parts[2]),
                int(parts[3]),
            )

        if parts[0] == "i":
            return (
                int(parts[1]),
                int(parts[2]),
                int(parts[3]),
            )

        return None, None, None

    # ======================================================
    # ДЕМО
    # ======================================================

    def fill_demo(self):

        if not messagebox.askyesno(
            "ДЕМО",
            "Заполнить программу тестовыми данными?\n\n"
            "Это искусственные данные."
        ):
            return

        self.diagnosis = create_demo()

        self._set_main_entry(self.client_name, "Тестовый клиент")

        self.request_text.delete(
            "1.0",
            "end"
        )
        self.request_text.insert(
            "1.0",
            self.diagnosis["request"]
        )

        self.refresh_situations()
        self.select_first_situation()

    def select_first_situation(self):

        if not self.diagnosis["situations"]:
            return

        self.situation_list.selection_set(0)
        self.on_situation_select()

    # ======================================================
    # ТЕКУЩАЯ СИТУАЦИЯ
    # ======================================================

    def current_situation(self):

        if self.selected_situation is None:
            return None

        situations = self.diagnosis["situations"]

        if not (
            0 <= self.selected_situation <
            len(situations)
        ):
            return None

        return situations[
            self.selected_situation
        ]

    # ======================================================
    # СОХРАНЕНИЕ TXT
    # ======================================================

    def safe_filename(self, text):

        text = text.strip()

        if not text:
            text = "Без_ФИО"

        text = re.sub(
            r'[<>:"/\\|?*]',
            "_",
            text
        )

        text = re.sub(
            r"\s+",
            "_",
            text
        )

        return text[:100]

    def build_txt(self):

        client = (
            self.client_name
            .get()
            .strip()
        )

        request = (
            self.request_text
            .get("1.0", "end")
            .strip()
        )

        now = datetime.now()

        lines = []

        lines.append(
            "ПСИХОЛОГИЧЕСКАЯ ДИАГНОСТИКА"
        )
        lines.append("=" * 70)
        lines.append(
            f"Дата: {now.strftime('%d.%m.%Y')}"
        )
        lines.append(
            f"Время: {now.strftime('%H:%M')}"
        )
        lines.append(
            f"Клиент: {client or 'Не указан'}"
        )
        lines.append("")
        lines.append(
            "ОБЩИЙ ЗАПРОС"
        )
        lines.append("-" * 70)
        lines.append(
            request or "Не указан"
        )
        lines.append("")

        situations = self.diagnosis.get(
            "situations",
            []
        )

        for si, situation in enumerate(
            situations,
            start=1
        ):

            lines.append(
                f"СИТУАЦИЯ {si}: "
                f'{situation.get("name", "")}'
            )

            lines.append(
                f'Уровень дискомфорта ситуации: '
                f'{situation.get("level", "")}/10'
            )

            lines.append("")

            beliefs = situation.get(
                "beliefs",
                []
            )

            for bi, belief in enumerate(
                beliefs,
                start=1
            ):

                lines.append(
                    f"  УБЕЖДЕНИЕ 1.{bi}: "
                    f'{belief.get("text", "")}'
                )

                lines.append(
                    f'  Уровень: '
                    f'{belief.get("level", 5)}/10'
                )

                if belief.get("comment"):
                    lines.append(
                        f'  Комментарий: '
                        f'{belief.get("comment")}'
                    )

                lines.append("")

                feelings = belief.get(
                    "feelings",
                    []
                )

                for fi, feeling in enumerate(
                    feelings,
                    start=1
                ):

                    lines.append(
                        f'    ВТОРИЧНОЕ ЧУВСТВО '
                        f'{bi}.{fi}: '
                        f'{feeling.get("text", "")}'
                    )

                    lines.append(
                        f'    Уровень: '
                        f'{feeling.get("level", 5)}/10'
                    )

                    if feeling.get("comment"):
                        lines.append(
                            f'    Комментарий: '
                            f'{feeling.get("comment")}'
                        )

                    lines.append("")

                    deep_list = feeling.get(
                        "deep",
                        []
                    )

                    for di, deep in enumerate(
                        deep_list,
                        start=1
                    ):

                        lines.append(
                            f'      УБЕЖДЕНИЕ 2.'
                            f'{bi}.{fi}.{di}: '
                            f'{deep.get("text", "")}'
                        )

                        lines.append(
                            f'      Уровень: '
                            f'{deep.get("level", 5)}/10'
                        )

                        if deep.get("comment"):
                            lines.append(
                                f'      Комментарий: '
                                f'{deep.get("comment")}'
                            )

                        instincts = self.get_instincts(deep)

                        for ii, instinct in enumerate(
                            instincts,
                            start=1
                        ):
                            if not instinct.get("name"):
                                continue

                            lines.append(
                                f'      ИНСТИНКТ {ii}: '
                                f'{instinct.get("name")}'
                            )

                            lines.append(
                                f'      Уровень инстинкта: '
                                f'{instinct.get("level", 5)}/10'
                            )

                            if instinct.get("comment"):
                                lines.append(
                                    f'      Комментарий инстинкта: '
                                    f'{instinct.get("comment")}'
                                )

                        lines.append("")

            lines.append(
                "  ЖЕЛАЕМЫЙ РЕЗУЛЬТАТ:"
            )

            lines.append(
                f'  {situation.get("result", "") or "Не указан"}'
            )

            lines.append("")
            lines.append("-" * 70)
            lines.append("")

        return "\n".join(lines)

    def save_txt(self):

        client = (
            self.client_name
            .get()
            .strip()
        )

        self.diagnosis["request"] = (
            self.request_text
            .get("1.0", "end")
            .strip()
        )

        if not client:
            messagebox.showwarning(
                "Сохранение",
                "Укажи ФИО клиента."
            )
            return

        # Сохраняем карточку клиента и текущее занятие
        # одновременно с TXT.
        if not self.save_current_session_to_db():
            return

        try:
            session_number = int(
                self.session_number.get()
            )
        except (TypeError, ValueError):
            session_number = 1

        output_dir = (
            Path(__file__).resolve().parent.parent
            / "output"
        )
        output_dir.mkdir(
            parents=True,
            exist_ok=True
        )

        safe_client = re.sub(
            r'[<>:"/\\|?*]',
            "_",
            client
        )

        filename = (
            f"{safe_client}_"
            f"{datetime.now().strftime('%Y-%m-%d_%H-%M')}_"
            "диагностика.txt"
        )

        path = output_dir / filename

        lines = []

        # ======================================================
        # ШАПКА
        # ======================================================

        lines.append(
            "╔════════════════════════════════════════════════════════════╗"
        )
        lines.append(
            "║                 ПСИХОЛОГИЧЕСКАЯ ДИАГНОСТИКА             ║"
        )
        lines.append(
            "╚════════════════════════════════════════════════════════════╝"
        )
        lines.append("")
        lines.append(f"КЛИЕНТ: {client}")
        lines.append(
            f"ТЕЛЕФОН: {self.client_phone.get().strip()}"
        )
        lines.append(
            f"E-MAIL: {self.client_email.get().strip()}"
        )
        lines.append(
            f"ЗАНЯТИЕ №: {session_number}"
        )
        lines.append(
            f"ДАТА: {datetime.now().strftime('%d.%m.%Y %H:%M')}"
        )
        lines.append("")
        lines.append("ОБЩИЙ ЗАПРОС")
        lines.append("────────────────────────────────────────────────────────────")
        lines.append(
            self.diagnosis.get("request", "")
        )
        lines.append("")

        def write_instincts(deep):
            instincts = deep.get("instincts")

            # Совместимость со старой версией:
            # раньше у убеждения хранился один instinct.
            if instincts is None:
                old = deep.get("instinct")
                instincts = [old] if old else []

            for instinct_index, instinct in enumerate(
                instincts,
                1
            ):
                if not instinct:
                    continue

                lines.append(
                    f"          ┌─ ИНСТИНКТ {instinct_index}: "
                    f"{instinct.get('name', '')}"
                )
                lines.append(
                    f"          │  Уровень: "
                    f"{instinct.get('level', 5)}/10"
                )

                comment = instinct.get("comment", "")
                if comment:
                    lines.append(
                        f"          │  Комментарий: {comment}"
                    )

                lines.append(
                    "          └────────────────────────────────────"
                )

        situations = self.diagnosis.get(
            "situations",
            []
        )

        for situation_index, situation in enumerate(
            situations,
            1
        ):
            # ==================================================
            # СИТУАЦИЯ
            # ==================================================

            lines.append(
                "╔════════════════════════════════════════════════════════════╗"
            )
            lines.append(
                f"║ СИТУАЦИЯ {situation_index}: "
                f"{situation.get('name', '')}"
            )
            lines.append(
                "╚════════════════════════════════════════════════════════════╝"
            )
            lines.append(
                f"Дискомфорт: {situation.get('level', 5)}/10"
            )

            situation_comment = situation.get(
                "comment",
                ""
            )
            if situation_comment:
                lines.append(
                    f"Комментарий: {situation_comment}"
                )

            lines.append("")

            beliefs = situation.get(
                "beliefs",
                []
            )

            # ==================================================
            # ПЕРВИЧНЫЕ УБЕЖДЕНИЯ
            # Каждое убеждение — отдельный визуальный блок.
            # ==================================================

            for belief_index, belief in enumerate(
                beliefs,
                1
            ):
                lines.append(
                    "┌────────────────────────────────────────────────────────────"
                )
                lines.append(
                    f"│ ПЕРВ. УБЕЖДЕНИЕ {belief_index}: "
                    f"{belief.get('text', '')}"
                )
                lines.append(
                    "└────────────────────────────────────────────────────────────"
                )
                lines.append(
                    f"  Уровень: {belief.get('level', 5)}/10"
                )

                belief_comment = belief.get(
                    "comment",
                    ""
                )
                if belief_comment:
                    lines.append(
                        f"  Комментарий: {belief_comment}"
                    )

                lines.append("")

                feelings = belief.get(
                    "feelings",
                    []
                )

                # Каждое первичное убеждение имеет
                # собственную нумерацию чувств.
                for feeling_index, feeling in enumerate(
                    feelings,
                    1
                ):
                    lines.append(
                        f"  ┌─ ВТОР. ЧУВСТВО {feeling_index}: "
                        f"{feeling.get('text', '')}"
                    )
                    lines.append(
                        f"  │  Уровень: "
                        f"{feeling.get('level', 5)}/10"
                    )

                    feeling_comment = feeling.get(
                        "comment",
                        ""
                    )
                    if feeling_comment:
                        lines.append(
                            f"  │  Комментарий: "
                            f"{feeling_comment}"
                        )

                    lines.append(
                        "  │"
                    )

                    deep_list = feeling.get(
                        "deep",
                        []
                    )

                    # Каждое чувство имеет собственную
                    # нумерацию глубинных убеждений.
                    for deep_index, deep in enumerate(
                        deep_list,
                        1
                    ):
                        lines.append(
                            f"  │  ┌─ ВТОР. УБЕЖДЕНИЕ {deep_index}: "
                            f"{deep.get('text', '')}"
                        )
                        lines.append(
                            f"  │  │  Уровень: "
                            f"{deep.get('level', 5)}/10"
                        )

                        deep_comment = deep.get(
                            "comment",
                            ""
                        )
                        if deep_comment:
                            lines.append(
                                f"  │  │  Комментарий: "
                                f"{deep_comment}"
                            )

                        write_instincts(deep)

                        lines.append(
                            "  │  └────────────────────────────────────"
                        )

                    lines.append(
                        "  └────────────────────────────────────────"
                    )
                    lines.append("")

                lines.append("")

            result = situation.get(
                "result",
                ""
            )

            if result:
                lines.append(
                    "  ★ ЖЕЛАЕМЫЙ РЕЗУЛЬТАТ СИТУАЦИИ"
                )
                lines.append(
                    "  ──────────────────────────────────────────"
                )
                lines.append(
                    f"  {result}"
                )
                lines.append("")

            # Между ситуациями — сильный разделитель.
            lines.append(
                "════════════════════════════════════════════════════════════"
            )
            lines.append("")

        path.write_text(
            "\n".join(lines),
            encoding="utf-8"
        )

        messagebox.showinfo(
            "Сохранение",
            f"Диагностика сохранена:\n\n{path}"
        )

    def run(self):
        self.root.mainloop()


# ==========================================================
# ДИАЛОГ ТЕКСТА
# ==========================================================

class TextDialog(tk.Toplevel):

    def __init__(
        self,
        parent,
        title,
        label,
        initial="",
    ):

        super().__init__(parent)

        self.result = None

        self.title(title)
        self.geometry("500x230")
        self.resizable(False, False)

        tk.Label(
            self,
            text=label,
            font=("Segoe UI", 10),
            anchor="w",
        ).pack(
            fill="x",
            padx=20,
            pady=(20, 6),
        )

        self.text = tk.Text(
            self,
            height=5,
            font=("Segoe UI", 10),
        )
        self.text.pack(
            fill="both",
            expand=True,
            padx=20,
        )

        if initial:
            self.text.insert(
                "1.0",
                initial
            )

        tk.Button(
            self,
            text="Сохранить",
            command=self.save,
            bg="#4169E1",
            fg="white",
            relief="flat",
            padx=15,
            pady=6,
        ).pack(
            anchor="e",
            padx=20,
            pady=15,
        )

        self.transient(parent)
        self.grab_set()

    def save(self):

        value = (
            self.text
            .get("1.0", "end")
            .strip()
        )

        if value:
            self.result = value
            self.destroy()


# ==========================================================
# ДИАЛОГ УРОВНЯ
# ==========================================================

class LevelDialog(tk.Toplevel):

    def __init__(
        self,
        parent,
        title,
        initial=5,
    ):

        super().__init__(parent)

        self.result = None

        self.title(title)
        self.geometry("300x170")
        self.resizable(False, False)

        tk.Label(
            self,
            text="Уровень 1–10",
        ).pack(
            pady=(25, 8)
        )

        self.level = ttk.Spinbox(
            self,
            from_=1,
            to=10,
            width=5,
        )
        try:
            initial = int(initial)
        except (TypeError, ValueError):
            initial = 5

        initial = max(1, min(10, initial))
        self.level.set(str(initial))
        self.level.pack()

        tk.Button(
            self,
            text="Сохранить",
            command=self.save,
            bg="#4169E1",
            fg="white",
            relief="flat",
            padx=15,
            pady=6,
        ).pack(
            pady=20
        )

        self.transient(parent)
        self.grab_set()

    def save(self):

        try:

            value = int(
                self.level.get()
            )

            if 1 <= value <= 10:
                self.result = value
                self.destroy()

        except ValueError:
            pass


# ==========================================================
# ВТОРИЧНЫЕ ЧУВСТВА — ГАЛОЧКИ
# ==========================================================

class SecondaryFeelingsDialog(tk.Toplevel):

    # Единая палитра строк. Цвета используются как мягкий визуальный
    # акцент, а не как "радуга".
    ROW_ACCENT = (
        "#4169E1",
        "#7C5CFC",
        "#18A873",
        "#E58A24",
        "#D94F70",
        "#2F8FA3",
    )

    NORMAL_COLOR = "#FFFFFF"
    HOVER_COLOR = "#EEF4FF"
    BORDER_COLOR = "#E1E7EF"
    ACTIVE_BORDER = "#AFC2E6"

    # Подсказки специалисту. Они появляются только при наведении
    # на название чувства.
    FEELING_HINTS = {
        "Боль": (
            "Что именно сейчас болит?\n"
            "Что в этой ситуации причиняет боль?\n"
            "Что хотелось бы изменить или прекратить?"
        ),
        "Обида": (
            "На кого направлена обида?\n"
            "Что человек сделал или не сделал?\n"
            "Каких ожиданий он не оправдал?"
        ),
        "Страх": (
            "Что самое страшное может произойти?\n"
            "Чего именно ты боишься?\n"
            "Что будет, если это действительно случится?"
        ),
        "Стыд": (
            "За что именно тебе стыдно?\n"
            "Что ты думаешь о себе в этот момент?\n"
            "Что, как тебе кажется, подумают о тебе другие?"
        ),
        "Вина": (
            "Кого ты винишь — себя или участников события?\n"
            "За что именно ты себя винишь?\n"
            "Что, по-твоему, ты должен был сделать иначе?"
        ),
        "Грусть": (
            "Что именно ты потерял или чего лишился?\n"
            "По чему ты грустишь?\n"
            "Чего хотелось бы вернуть?"
        ),
        "Злость": (
            "На кого направлена злость?\n"
            "Что именно тебя разозлило?\n"
            "Что хотелось сделать в этот момент?"
        ),
        "Разочарование": (
            "На что ты рассчитывал?\n"
            "Что произошло вместо этого?\n"
            "В ком или в чём ты разочаровался?"
        ),
        "Одиночество": (
            "Чего не хватает рядом с другими людьми?\n"
            "С кем хотелось бы быть рядом?\n"
            "Что особенно тяжело переживать одному?"
        ),
        "Беспомощность": (
            "Что ты не можешь изменить или контролировать?\n"
            "Что хотелось бы сделать, но не получается?\n"
            "Что мешает действовать?"
        ),
        "Тревога": (
            "Что может произойти плохого?\n"
            "Что сейчас находится под угрозой?\n"
            "Чего ты ожидаешь с наибольшим напряжением?"
        ),
        "Унижение": (
            "Что именно заставило почувствовать себя униженным?\n"
            "Кто или что тебя унизило?\n"
            "Что это говорит о тебе в твоём восприятии?"
        ),
        "Зависть": (
            "Чему именно ты завидуешь?\n"
            "Что есть у другого, чего хочется тебе?\n"
            "Что это говорит о твоих собственных желаниях?"
        ),
        "Ревность": (
            "Кого ты боишься потерять?\n"
            "Что кажется угрозой отношениям?\n"
            "Чего ты опасаешься больше всего?"
        ),
    }

    def __init__(
        self,
        parent,
        belief,
    ):

        super().__init__(parent)

        self.result = None
        self.belief = belief
        self.hovered_item = None
        self.tooltip = None
        self.tooltip_job = None

        self.title("Вторичные чувства")
        self.geometry("900x700")
        self.minsize(780, 620)
        self.configure(bg="#F5F7FA")

        header_frame = tk.Frame(
            self,
            bg="#F5F7FA"
        )
        header_frame.pack(
            fill="x",
            padx=24,
            pady=(20, 8)
        )

        tk.Label(
            header_frame,
            text="ВТОРИЧНЫЕ ЧУВСТВА",
            font=("Segoe UI", 13, "bold"),
            bg="#F5F7FA",
            fg="#172033",
        ).pack(anchor="w")

        tk.Label(
            header_frame,
            text=(
                "Выбери подходящие чувства. "
                "Наведись на название — появится подсказка специалисту."
            ),
            font=("Segoe UI", 9),
            bg="#F5F7FA",
            fg="#667085",
        ).pack(anchor="w", pady=(4, 0))

        outer = tk.Frame(
            self,
            bg="#FFFFFF",
            highlightbackground="#D9E0EA",
            highlightthickness=1,
        )
        outer.pack(
            fill="both",
            expand=True,
            padx=24,
            pady=(4, 0),
        )

        canvas = tk.Canvas(
            outer,
            bg="#FFFFFF",
            highlightthickness=0,
        )

        scrollbar = ttk.Scrollbar(
            outer,
            orient="vertical",
            command=canvas.yview,
        )

        self.rows_frame = tk.Frame(
            canvas,
            bg="#FFFFFF",
        )

        window_id = canvas.create_window(
            (0, 0),
            window=self.rows_frame,
            anchor="nw",
        )

        def update_scroll(_event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def resize_frame(event):
            canvas.itemconfigure(window_id, width=event.width)

        self.rows_frame.bind("<Configure>", update_scroll)
        canvas.bind("<Configure>", resize_frame)
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(
            side="left",
            fill="both",
            expand=True,
            padx=(10, 0),
            pady=10,
        )
        scrollbar.pack(
            side="right",
            fill="y",
            padx=(0, 8),
            pady=10,
        )

        # Одинаковая сетка для заголовка и всех строк.
        # Это устраняет "съезд" колонок, который был при pack().
        self.rows_frame.grid_columnconfigure(0, minsize=46, weight=0)
        self.rows_frame.grid_columnconfigure(1, minsize=250, weight=5)
        self.rows_frame.grid_columnconfigure(2, minsize=90, weight=0)
        self.rows_frame.grid_columnconfigure(3, minsize=300, weight=7)

        header = tk.Frame(
            self.rows_frame,
            bg="#E9EEF5",
            height=40,
        )
        header.grid(
            row=0,
            column=0,
            columnspan=4,
            sticky="ew",
            pady=(0, 6),
        )
        header.grid_propagate(False)

        header.grid_columnconfigure(0, minsize=46, weight=0)
        header.grid_columnconfigure(1, minsize=250, weight=5)
        header.grid_columnconfigure(2, minsize=90, weight=0)
        header.grid_columnconfigure(3, minsize=300, weight=7)

        tk.Label(
            header,
            text="",
            bg="#E9EEF5",
        ).grid(row=0, column=0, sticky="nsew")

        tk.Label(
            header,
            text="Вторичное чувство",
            font=("Segoe UI", 9, "bold"),
            bg="#E9EEF5",
            fg="#475467",
            anchor="w",
        ).grid(row=0, column=1, sticky="w", padx=(8, 4))

        tk.Label(
            header,
            text="Уровень",
            font=("Segoe UI", 9, "bold"),
            bg="#E9EEF5",
            fg="#475467",
            anchor="center",
        ).grid(row=0, column=2, sticky="nsew")

        tk.Label(
            header,
            text="Комментарий / уточнение",
            font=("Segoe UI", 9, "bold"),
            bg="#E9EEF5",
            fg="#475467",
            anchor="w",
        ).grid(row=0, column=3, sticky="w", padx=(8, 8))

        existing = {
            item.get("text", ""): item
            for item in belief.get("feelings", [])
        }

        self.vars = []

        for index, name in enumerate(SECONDARY_FEELINGS, start=1):
            accent_color = self.ROW_ACCENT[
                (index - 1) % len(self.ROW_ACCENT)
            ]

            row = tk.Frame(
                self.rows_frame,
                bg=self.NORMAL_COLOR,
                cursor="hand2",
                highlightthickness=1,
                highlightbackground=self.BORDER_COLOR,
            )
            row.grid(
                row=index,
                column=0,
                columnspan=4,
                sticky="ew",
                pady=2,
                padx=2,
            )

            row.grid_columnconfigure(0, minsize=46, weight=0)
            row.grid_columnconfigure(1, minsize=250, weight=5)
            row.grid_columnconfigure(2, minsize=90, weight=0)
            row.grid_columnconfigure(3, minsize=300, weight=7)

            accent = tk.Frame(
                row,
                width=4,
                bg=accent_color if name in existing else "#D7DDE6",
            )
            accent.grid(
                row=0,
                column=0,
                sticky="nsw",
            )
            accent.grid_propagate(False)

            checked = tk.BooleanVar(
                value=name in existing
            )

            check = tk.Checkbutton(
                row,
                variable=checked,
                bg=self.NORMAL_COLOR,
                activebackground=self.NORMAL_COLOR,
                cursor="hand2",
                relief="flat",
                bd=0,
                highlightthickness=0,
                padx=0,
            )
            check.grid(
                row=0,
                column=0,
                sticky="e",
                padx=(8, 6),
                pady=6,
            )

            name_label = tk.Label(
                row,
                text=name,
                font=("Segoe UI", 10),
                bg=self.NORMAL_COLOR,
                fg="#172033",
                anchor="w",
                cursor="hand2",
            )
            name_label.grid(
                row=0,
                column=1,
                sticky="ew",
                padx=(4, 8),
                pady=6,
            )

            level = ttk.Spinbox(
                row,
                from_=1,
                to=10,
                width=5,
            )
            level.set(
                str(
                    existing.get(
                        name,
                        {}
                    ).get(
                        "level",
                        5
                    )
                )
            )
            level.grid(
                row=0,
                column=2,
                sticky="n",
                padx=10,
                pady=5,
            )

            comment = tk.Entry(
                row,
                font=("Segoe UI", 9),
                bg="#F8F9FA",
                fg="#344054",
                relief="flat",
                highlightthickness=1,
                highlightbackground="#D9E0EA",
                highlightcolor="#4169E1",
            )
            comment.insert(
                0,
                existing.get(
                    name,
                    {}
                ).get(
                    "comment",
                    ""
                )
            )
            comment.grid(
                row=0,
                column=3,
                sticky="ew",
                padx=(0, 8),
                pady=5,
                ipady=4,
            )

            item = {
                "name": name,
                "checked": checked,
                "level": level,
                "comment": comment,
                "row": row,
                "accent": accent,
                "check": check,
                "label": name_label,
                "accent_color": accent_color,
            }

            self.vars.append(item)

            checked.trace_add(
                "write",
                lambda *_args, item=item:
                    self.update_row_style(item)
            )

            # Наведение работает по названию чувства и всей строке.
            for widget in (
                row,
                accent,
                check,
                name_label,
            ):
                widget.bind(
                    "<Enter>",
                    lambda event, item=item:
                        self.hover_row(item, True, event)
                )
                widget.bind(
                    "<Leave>",
                    lambda event, item=item:
                        self.hover_row(item, False, event)
                )

            row.bind(
                "<Button-1>",
                lambda _event, item=item:
                    self.toggle_row(item)
            )

            name_label.bind(
                "<Button-1>",
                lambda _event, item=item:
                    self.toggle_row(item)
            )

            check.bind(
                "<Button-1>",
                lambda _event, item=item:
                    self.checkbox_click(item)
            )

        bottom = tk.Frame(
            self,
            bg="#F5F7FA"
        )
        bottom.pack(
            fill="x",
            padx=24,
            pady=16,
        )

        tk.Button(
            bottom,
            text="Отмена",
            command=self.cancel,
            bg="#E9EEF5",
            fg="#344054",
            relief="flat",
            bd=0,
            padx=18,
            pady=8,
            cursor="hand2",
        ).pack(side="right")

        tk.Button(
            bottom,
            text="Сохранить выбранные",
            command=self.save,
            bg="#4169E1",
            fg="white",
            relief="flat",
            bd=0,
            padx=18,
            pady=8,
            cursor="hand2",
        ).pack(side="right", padx=8)

        self.transient(parent)
        self.grab_set()

    def update_row_style(self, item):
        if self.hovered_item is item:
            return

        if item["checked"].get():
            color = "#F3F6FF"
            border = "#C8D5F0"
            accent = item["accent_color"]
        else:
            color = self.NORMAL_COLOR
            border = self.BORDER_COLOR
            accent = "#D7DDE6"

        self.set_row_background(
            item,
            color,
        )

        item["row"].configure(
            highlightbackground=border
        )

        item["accent"].configure(
            bg=accent
        )

    def set_row_background(self, item, color):
        item["row"].configure(
            bg=color
        )
        item["check"].configure(
            bg=color,
            activebackground=color,
        )
        item["label"].configure(
            bg=color
        )

    def hover_row(self, item, entering, event=None):
        if entering:
            self.hovered_item = item

            self.set_row_background(
                item,
                self.HOVER_COLOR,
            )

            item["row"].configure(
                highlightbackground=self.ACTIVE_BORDER
            )

            # Подсказка появляется только при наведении
            # именно на название чувства.
            if event is not None:
                self.show_tooltip_delayed(
                    item,
                    event
                )

        else:
            if self.hovered_item is item:
                self.hovered_item = None

            self.hide_tooltip()

            self.update_row_style(item)

    def toggle_row(self, item):
        item["checked"].set(
            not item["checked"].get()
        )

    def checkbox_click(self, item):
        # Checkbox сам переключит BooleanVar.
        # Не переключаем второй раз.
        self.hovered_item = item

    def show_tooltip_delayed(self, item, event):
        self.cancel_tooltip_job()

        if item["name"] not in self.FEELING_HINTS:
            return

        self.tooltip_job = self.after(
            350,
            lambda item=item:
                self.show_tooltip(item)
        )

    def show_tooltip(self, item):
        if self.hovered_item is not item:
            return

        self.hide_tooltip()

        text = self.FEELING_HINTS.get(
            item["name"]
        )

        if not text:
            return

        self.tooltip = tk.Toplevel(self)
        self.tooltip.wm_overrideredirect(True)
        self.tooltip.attributes(
            "-topmost",
            True
        )

        frame = tk.Frame(
            self.tooltip,
            bg="#172033",
            highlightthickness=1,
            highlightbackground="#344054",
        )
        frame.pack()

        tk.Label(
            frame,
            text=f"{item['name']}",
            font=("Segoe UI", 10, "bold"),
            bg="#172033",
            fg="white",
            anchor="w",
            justify="left",
        ).pack(
            anchor="w",
            padx=12,
            pady=(9, 3),
        )

        tk.Label(
            frame,
            text=text,
            font=("Segoe UI", 9),
            bg="#172033",
            fg="#E6EAF0",
            anchor="w",
            justify="left",
        ).pack(
            anchor="w",
            padx=12,
            pady=(0, 10),
        )

        x = self.winfo_pointerx() + 14
        y = self.winfo_pointery() + 14

        self.tooltip.geometry(
            f"+{x}+{y}"
        )

    def cancel_tooltip_job(self):
        if self.tooltip_job is not None:
            try:
                self.after_cancel(
                    self.tooltip_job
                )
            except tk.TclError:
                pass

            self.tooltip_job = None

    def hide_tooltip(self):
        self.cancel_tooltip_job()

        if self.tooltip is not None:
            try:
                self.tooltip.destroy()
            except tk.TclError:
                pass

            self.tooltip = None

    def save(self):
        result = []

        for item in self.vars:

            if not item["checked"].get():
                continue

            try:
                level = int(
                    item["level"].get()
                )
            except ValueError:
                level = 5

            result.append(
                {
                    "name": item["name"],
                    "level": max(
                        1,
                        min(
                            10,
                            level
                        )
                    ),
                    "comment": (
                        item["comment"]
                        .get()
                        .strip()
                    ),
                }
            )

        # Пустой список допустим:
        # можно снять все ранее выбранные чувства.
        self.hide_tooltip()
        self.result = result
        self.destroy()

    def cancel(self):
        self.hide_tooltip()
        self.result = None
        self.destroy()


# ==========================================================
# ЗАПУСК
# ==========================================================

if __name__ == "__main__":

    root = tk.Tk()

    app = MainWindow(root)

    app.run()
