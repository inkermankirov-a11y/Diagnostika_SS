@echo off
chcp 65001 >nul
title Johnny3D Studio - Developer Tools

:MENU
cls
echo ==========================================================
echo               JOHNNY3D STUDIO DEV TOOLS
echo ==========================================================
echo.
echo 1. Запустить программу
echo 2. Сгенерировать project_log.txt
echo 3. Сгенерировать structure.txt
echo 4. Очистить __pycache__
echo 5. Открыть папку проекта
echo 6. Выход
echo.
set /p choice=Выберите пункт:

if "%choice%"=="1" goto RUN
if "%choice%"=="2" goto LOG
if "%choice%"=="3" goto TREE
if "%choice%"=="4" goto CLEAN
if "%choice%"=="5" goto OPEN
if "%choice%"=="6" exit

goto MENU


:RUN
cls
cd /d "%~dp0"
python Johnny3D.py
pause
goto MENU


:LOG
cls
cd /d "%~dp0"
python make_project_log.py
echo.
pause
goto MENU


:TREE
cls
cd /d "%~dp0"
tree /F /A > structure.txt
echo.
echo structure.txt создан.
pause
goto MENU


:CLEAN
cls
cd /d "%~dp0"

echo Удаление __pycache__...

for /d /r %%d in (__pycache__) do (
    if exist "%%d" rd /s /q "%%d"
)

echo.
echo Готово.
pause
goto MENU


:OPEN
start "" "%~dp0"
goto MENU