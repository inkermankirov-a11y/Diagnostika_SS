# -*- coding: utf-8 -*-

from copy import deepcopy


# ============================================================
# СТРУКТУРА ДИАГНОСТИКИ
# ============================================================

def new_diagnosis():
    return {
        "request": "",
        "situations": []
    }


def new_situation(name="", level=1):
    return {
        "name": name,
        "level": level,
        "comment": "",
        "beliefs": [],
        "result": ""
    }


def new_belief1(text="", level=1):
    return {
        "text": text,
        "level": level,
        "comment": "",
        "feelings": []
    }


def new_feeling(
    name="",
    level=1,
    comment=""
):
    return {
        "text": name,
        "level": level,
        "comment": comment,
        "deep": []
    }


def new_belief2(
    text="",
    level=1,
    comment=""
):
    return {
        "text": text,
        "level": level,
        "comment": comment,

        # Один или несколько инстинктов.
        # Первый создаётся сразу с уровнем 5.
        "instincts": [
            {
                "name": "",
                "level": 5,
                "comment": ""
            }
        ],
        # Старое поле оставляем для обратной совместимости
        # со старыми TXT/диагностиками.
        "instinct": {
            "name": "",
            "level": 5,
            "comment": ""
        }
    }


# ============================================================
# ПРОВЕРКА УРОВНЯ
# ============================================================

def normalize_level(value):

    try:
        value = int(value)
    except (
        TypeError,
        ValueError
    ):
        value = 1

    return max(
        1,
        min(
            10,
            value
        )
    )


# ============================================================
# СИТУАЦИИ
# ============================================================

def add_situation(
    diagnosis,
    name,
    level=1,
    comment=""
):

    situation = new_situation(
        name=name,
        level=normalize_level(level)
    )

    situation["comment"] = comment

    diagnosis["situations"].append(
        situation
    )

    return situation


def delete_situation(
    diagnosis,
    index
):

    if not valid_situation(
        diagnosis,
        index
    ):
        return False

    del diagnosis["situations"][index]

    return True


def valid_situation(
    diagnosis,
    index
):

    return (
        isinstance(index, int)
        and
        0 <= index <
        len(diagnosis["situations"])
    )


# ============================================================
# УБЕЖДЕНИЯ 1
# ============================================================

def add_belief1(
    situation,
    text,
    level=1,
    comment=""
):

    belief = new_belief1(
        text=text,
        level=normalize_level(level)
    )

    belief["comment"] = comment

    situation["beliefs"].append(
        belief
    )

    return belief


def delete_belief1(
    situation,
    index
):

    if not valid_index(
        situation.get("beliefs"),
        index
    ):
        return False

    del situation["beliefs"][index]

    return True


# ============================================================
# ВТОРИЧНЫЕ ЧУВСТВА
# ============================================================

def add_feeling(
    belief1,
    name,
    level=1,
    comment=""
):

    feeling = new_feeling(
        name=name,
        level=normalize_level(level),
        comment=comment
    )

    belief1["feelings"].append(
        feeling
    )

    return feeling


def delete_feeling(
    belief1,
    index
):

    if not valid_index(
        belief1.get("feelings"),
        index
    ):
        return False

    del belief1["feelings"][index]

    return True


# ============================================================
# УБЕЖДЕНИЯ 2
# ============================================================

def add_belief2(
    feeling,
    text,
    level=1,
    comment=""
):

    deep = new_belief2(
        text=text,
        level=normalize_level(level),
        comment=comment
    )

    feeling["deep"].append(
        deep
    )

    return deep


def delete_belief2(
    feeling,
    index
):

    if not valid_index(
        feeling.get("deep"),
        index
    ):
        return False

    del feeling["deep"][index]

    return True


# ============================================================
# ИНСТИНКТ
# ============================================================

INSTINCTS = (
    "Бей / атаковать",
    "Беги / убежать",
    "Замри / спрятаться",
)


def _ensure_instincts(belief2):

    instincts = belief2.get("instincts")

    if isinstance(instincts, list) and instincts:
        return instincts

    old = belief2.get("instinct")
    if isinstance(old, dict):
        first = {
            "name": old.get("name", ""),
            "level": normalize_level(old.get("level", 5)),
            "comment": old.get("comment", ""),
        }
    else:
        first = {
            "name": "",
            "level": 5,
            "comment": "",
        }

    belief2["instincts"] = [first]
    return belief2["instincts"]


def add_instinct(belief2):

    instincts = _ensure_instincts(belief2)

    instinct = {
        "name": "",
        "level": 5,
        "comment": "",
    }

    instincts.append(instinct)
    return instinct


def set_instinct(
    belief2,
    name,
    level=5,
    comment="",
    index=0
):

    if name not in INSTINCTS:
        raise ValueError(
            "Недопустимый тип инстинкта."
        )

    instincts = _ensure_instincts(belief2)

    while len(instincts) <= index:
        add_instinct(belief2)

    instincts[index] = {
        "name": name,
        "level": normalize_level(level),
        "comment": comment
    }

    if index == 0:
        belief2["instinct"] = dict(instincts[0])

    return instincts[index]


def clear_instinct(
    belief2,
    index=0
):

    instincts = _ensure_instincts(belief2)

    while len(instincts) <= index:
        add_instinct(belief2)

    instincts[index] = {
        "name": "",
        "level": 5,
        "comment": ""
    }

    if index == 0:
        belief2["instinct"] = dict(instincts[0])


# ============================================================
# РЕЗУЛЬТАТ СИТУАЦИИ
# ============================================================

def set_result(
    situation,
    result
):

    situation["result"] = (
        result or ""
    ).strip()


# ============================================================
# ОБНОВЛЕНИЕ ЭЛЕМЕНТА
# ============================================================

def update_element(
    element,
    text=None,
    level=None,
    comment=None
):

    if text is not None:
        element["text"] = (
            str(text).strip()
        )

    if level is not None:
        element["level"] = (
            normalize_level(level)
        )

    if comment is not None:
        element["comment"] = (
            str(comment).strip()
        )


# ============================================================
# ПРОВЕРКА СТРУКТУРЫ
# ============================================================

def valid_index(
    collection,
    index
):

    return (
        isinstance(
            collection,
            list
        )
        and
        isinstance(
            index,
            int
        )
        and
        0 <= index <
        len(collection)
    )


# ============================================================
# ГЛУБИННАЯ КОПИЯ
# ============================================================

def copy_diagnosis(
    diagnosis
):

    return deepcopy(
        diagnosis
    )


# ============================================================
# БЕЗОПАСНОЕ ДЕМО-ЗАПОЛНЕНИЕ
# ============================================================

def create_demo():

    diagnosis = new_diagnosis()

    diagnosis["request"] = (
        "Не могу найти работу от 100 000 ₽"
    )

    situation = add_situation(
        diagnosis,
        "Отсутствие опыта",
        8,
        "ДЕМО: искусственные данные"
    )

    belief1 = add_belief1(
        situation,
        "Я недостаточно компетентна",
        7,
        "Поверхностное убеждение о себе"
    )

    feeling1 = add_feeling(
        belief1,
        "Обида",
        7,
        "Обида на себя"
    )

    belief2 = add_belief2(
        feeling1,
        "Я не справляюсь",
        6,
        "Глубинное убеждение"
    )

    set_instinct(
        belief2,
        "Замри / спрятаться",
        7,
        "Хочется скрыться от ситуации"
    )

    add_feeling(
        belief1,
        "Грусть",
        7,
        "Грусть из-за ситуации"
    )

    add_feeling(
        belief1,
        "Разочарование",
        7,
        "Разочарование в себе"
    )

    belief1_second = add_belief1(
        situation,
        "Я ничего не умею",
        5,
        "ДЕМО"
    )

    feeling2 = add_feeling(
        belief1_second,
        "Страх",
        6,
        "Страх неудачи"
    )

    belief2_second = add_belief2(
        feeling2,
        "Со мной что-то не так",
        6,
        "Глубинное убеждение"
    )

    set_instinct(
        belief2_second,
        "Беги / убежать",
        6,
        "Хочется уйти из ситуации"
    )

    set_result(
        situation,
        "Найти работу от 100 000 ₽ "
        "и чувствовать себя уверенно."
    )

    add_situation(
        diagnosis,
        "Страх собеседования",
        6,
        "ДЕМО"
    )

    add_situation(
        diagnosis,
        "Маленькая зарплата",
        9,
        "ДЕМО"
    )

    return diagnosis